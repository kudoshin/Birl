/*******************************************************************************
* File Name: XY_DATAREADY.h  
* Version 2.5
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_XY_DATAREADY_H) /* Pins XY_DATAREADY_H */
#define CY_PINS_XY_DATAREADY_H

#include "cytypes.h"
#include "cyfitter.h"
#include "XY_DATAREADY_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    XY_DATAREADY_Write(uint8 value) ;
void    XY_DATAREADY_SetDriveMode(uint8 mode) ;
uint8   XY_DATAREADY_ReadDataReg(void) ;
uint8   XY_DATAREADY_Read(void) ;
uint8   XY_DATAREADY_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define XY_DATAREADY_DRIVE_MODE_BITS        (3)
#define XY_DATAREADY_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - XY_DATAREADY_DRIVE_MODE_BITS))
#define XY_DATAREADY_DRIVE_MODE_SHIFT       (0x00u)
#define XY_DATAREADY_DRIVE_MODE_MASK        (0x07u << XY_DATAREADY_DRIVE_MODE_SHIFT)

#define XY_DATAREADY_DM_ALG_HIZ         (0x00u << XY_DATAREADY_DRIVE_MODE_SHIFT)
#define XY_DATAREADY_DM_DIG_HIZ         (0x01u << XY_DATAREADY_DRIVE_MODE_SHIFT)
#define XY_DATAREADY_DM_RES_UP          (0x02u << XY_DATAREADY_DRIVE_MODE_SHIFT)
#define XY_DATAREADY_DM_RES_DWN         (0x03u << XY_DATAREADY_DRIVE_MODE_SHIFT)
#define XY_DATAREADY_DM_OD_LO           (0x04u << XY_DATAREADY_DRIVE_MODE_SHIFT)
#define XY_DATAREADY_DM_OD_HI           (0x05u << XY_DATAREADY_DRIVE_MODE_SHIFT)
#define XY_DATAREADY_DM_STRONG          (0x06u << XY_DATAREADY_DRIVE_MODE_SHIFT)
#define XY_DATAREADY_DM_RES_UPDWN       (0x07u << XY_DATAREADY_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define XY_DATAREADY_MASK               XY_DATAREADY__MASK
#define XY_DATAREADY_SHIFT              XY_DATAREADY__SHIFT
#define XY_DATAREADY_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define XY_DATAREADY_PS                     (* (reg32 *) XY_DATAREADY__PS)
/* Port Configuration */
#define XY_DATAREADY_PC                     (* (reg32 *) XY_DATAREADY__PC)
/* Data Register */
#define XY_DATAREADY_DR                     (* (reg32 *) XY_DATAREADY__DR)
/* Input Buffer Disable Override */
#define XY_DATAREADY_INP_DIS                (* (reg32 *) XY_DATAREADY__PC2)


#if defined(XY_DATAREADY__INTSTAT)  /* Interrupt Registers */

    #define XY_DATAREADY_INTSTAT                (* (reg32 *) XY_DATAREADY__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins XY_DATAREADY_H */


/* [] END OF FILE */
