/*******************************************************************************
* File Name: CapSense_1_Sns.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CapSense_1_Sns_ALIASES_H) /* Pins CapSense_1_Sns_ALIASES_H */
#define CY_PINS_CapSense_1_Sns_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define CapSense_1_Sns_0		CapSense_1_Sns__0__PC
#define CapSense_1_Sns_1		CapSense_1_Sns__1__PC
#define CapSense_1_Sns_2		CapSense_1_Sns__2__PC
#define CapSense_1_Sns_3		CapSense_1_Sns__3__PC
#define CapSense_1_Sns_4		CapSense_1_Sns__4__PC
#define CapSense_1_Sns_5		CapSense_1_Sns__5__PC
#define CapSense_1_Sns_6		CapSense_1_Sns__6__PC
#define CapSense_1_Sns_7		CapSense_1_Sns__7__PC

#define CapSense_1_Sns_Touchpad0_Col0__TP		CapSense_1_Sns__Touchpad0_Col0__TP__PC
#define CapSense_1_Sns_Touchpad0_Col1__TP		CapSense_1_Sns__Touchpad0_Col1__TP__PC
#define CapSense_1_Sns_Touchpad0_Col2__TP		CapSense_1_Sns__Touchpad0_Col2__TP__PC
#define CapSense_1_Sns_Touchpad0_Col3__TP		CapSense_1_Sns__Touchpad0_Col3__TP__PC
#define CapSense_1_Sns_Touchpad0_Row0__TP		CapSense_1_Sns__Touchpad0_Row0__TP__PC
#define CapSense_1_Sns_Touchpad0_Row1__TP		CapSense_1_Sns__Touchpad0_Row1__TP__PC
#define CapSense_1_Sns_Touchpad0_Row2__TP		CapSense_1_Sns__Touchpad0_Row2__TP__PC
#define CapSense_1_Sns_Touchpad0_Row3__TP		CapSense_1_Sns__Touchpad0_Row3__TP__PC

#endif /* End Pins CapSense_1_Sns_ALIASES_H */


/* [] END OF FILE */
