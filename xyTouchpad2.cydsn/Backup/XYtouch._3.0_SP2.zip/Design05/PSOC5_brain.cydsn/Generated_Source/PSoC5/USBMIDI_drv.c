/*******************************************************************************
* File Name: USBMIDI_drv.c
* Version 2.70
*
* Description:
*  Endpoint 0 Driver for the USBFS Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "USBMIDI.h"
#include "USBMIDI_pvt.h"


/***************************************
* Global data allocation
***************************************/

volatile T_USBMIDI_EP_CTL_BLOCK USBMIDI_EP[USBMIDI_MAX_EP];
volatile uint8 USBMIDI_configuration;
volatile uint8 USBMIDI_interfaceNumber;
volatile uint8 USBMIDI_configurationChanged;
volatile uint8 USBMIDI_deviceAddress;
volatile uint8 USBMIDI_deviceStatus;
volatile uint8 USBMIDI_interfaceSetting[USBMIDI_MAX_INTERFACES_NUMBER];
volatile uint8 USBMIDI_interfaceSetting_last[USBMIDI_MAX_INTERFACES_NUMBER];
volatile uint8 USBMIDI_interfaceStatus[USBMIDI_MAX_INTERFACES_NUMBER];
volatile uint8 USBMIDI_device;
const uint8 CYCODE *USBMIDI_interfaceClass;


/***************************************
* Local data allocation
***************************************/

volatile uint8 USBMIDI_ep0Toggle;
volatile uint8 USBMIDI_lastPacketSize;
volatile uint8 USBMIDI_transferState;
volatile T_USBMIDI_TD USBMIDI_currentTD;
volatile uint8 USBMIDI_ep0Mode;
volatile uint8 USBMIDI_ep0Count;
volatile uint16 USBMIDI_transferByteCount;


/*******************************************************************************
* Function Name: USBMIDI_ep_0_Interrupt
********************************************************************************
*
* Summary:
*  This Interrupt Service Routine handles Endpoint 0 (Control Pipe) traffic.
*  It dispatches setup requests and handles the data and status stages.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
CY_ISR(USBMIDI_EP_0_ISR)
{
    uint8 bRegTemp;
    uint8 modifyReg;


    bRegTemp = CY_GET_REG8(USBMIDI_EP0_CR_PTR);
    if ((bRegTemp & USBMIDI_MODE_ACKD) != 0u)
    {
        modifyReg = 1u;
        if ((bRegTemp & USBMIDI_MODE_SETUP_RCVD) != 0u)
        {
            if((bRegTemp & USBMIDI_MODE_MASK) != USBMIDI_MODE_NAK_IN_OUT)
            {
                modifyReg = 0u;                                     /* When mode not NAK_IN_OUT => invalid setup */
            }
            else
            {
                USBMIDI_HandleSetup();
                if((USBMIDI_ep0Mode & USBMIDI_MODE_SETUP_RCVD) != 0u)
                {
                    modifyReg = 0u;                         /* if SETUP bit set -> exit without modifying the mode */
                }

            }
        }
        else if ((bRegTemp & USBMIDI_MODE_IN_RCVD) != 0u)
        {
            USBMIDI_HandleIN();
        }
        else if ((bRegTemp & USBMIDI_MODE_OUT_RCVD) != 0u)
        {
            USBMIDI_HandleOUT();
        }
        else
        {
            modifyReg = 0u;
        }
        if(modifyReg != 0u)
        {
            bRegTemp = CY_GET_REG8(USBMIDI_EP0_CR_PTR);    /* unlock registers */
            if((bRegTemp & USBMIDI_MODE_SETUP_RCVD) == 0u)  /* Check if SETUP bit is not set, otherwise exit */
            {
                /* Update the count register */
                bRegTemp = USBMIDI_ep0Toggle | USBMIDI_ep0Count;
                CY_SET_REG8(USBMIDI_EP0_CNT_PTR, bRegTemp);
                if(bRegTemp == CY_GET_REG8(USBMIDI_EP0_CNT_PTR))   /* continue if writing was successful */
                {
                    do
                    {
                        modifyReg = USBMIDI_ep0Mode;       /* Init temporary variable */
                        /* Unlock registers */
                        bRegTemp = CY_GET_REG8(USBMIDI_EP0_CR_PTR) & USBMIDI_MODE_SETUP_RCVD;
                        if(bRegTemp == 0u)                          /* Check if SETUP bit is not set */
                        {
                            /* Set the Mode Register  */
                            CY_SET_REG8(USBMIDI_EP0_CR_PTR, USBMIDI_ep0Mode);
                            /* Writing check */
                            modifyReg = CY_GET_REG8(USBMIDI_EP0_CR_PTR) & USBMIDI_MODE_MASK;
                        }
                    }while(modifyReg != USBMIDI_ep0Mode);  /* Repeat if writing was not successful */
                }
            }
        }
    }
}


/*******************************************************************************
* Function Name: USBMIDI_HandleSetup
********************************************************************************
*
* Summary:
*  This Routine dispatches requests for the four USB request types
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_HandleSetup(void) 
{
    uint8 requestHandled;

    requestHandled = CY_GET_REG8(USBMIDI_EP0_CR_PTR);      /* unlock registers */
    CY_SET_REG8(USBMIDI_EP0_CR_PTR, requestHandled);       /* clear setup bit */
    requestHandled = CY_GET_REG8(USBMIDI_EP0_CR_PTR);      /* reread register */
    if((requestHandled & USBMIDI_MODE_SETUP_RCVD) != 0u)
    {
        USBMIDI_ep0Mode = requestHandled;        /* if SETUP bit set -> exit without modifying the mode */
    }
    else
    {
        /* In case the previous transfer did not complete, close it out */
        USBMIDI_UpdateStatusBlock(USBMIDI_XFER_PREMATURE);

        switch (CY_GET_REG8(USBMIDI_bmRequestType) & USBMIDI_RQST_TYPE_MASK)
        {
            case USBMIDI_RQST_TYPE_STD:
                requestHandled = USBMIDI_HandleStandardRqst();
                break;
            case USBMIDI_RQST_TYPE_CLS:
                requestHandled = USBMIDI_DispatchClassRqst();
                break;
            case USBMIDI_RQST_TYPE_VND:
                requestHandled = USBMIDI_HandleVendorRqst();
                break;
            default:
                requestHandled = USBMIDI_FALSE;
                break;
        }
        if (requestHandled == USBMIDI_FALSE)
        {
            USBMIDI_ep0Mode = USBMIDI_MODE_STALL_IN_OUT;
        }
    }
}


/*******************************************************************************
* Function Name: USBMIDI_HandleIN
********************************************************************************
*
* Summary:
*  This routine handles EP0 IN transfers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_HandleIN(void) 
{
    switch (USBMIDI_transferState)
    {
        case USBMIDI_TRANS_STATE_IDLE:
            break;
        case USBMIDI_TRANS_STATE_CONTROL_READ:
            USBMIDI_ControlReadDataStage();
            break;
        case USBMIDI_TRANS_STATE_CONTROL_WRITE:
            USBMIDI_ControlWriteStatusStage();
            break;
        case USBMIDI_TRANS_STATE_NO_DATA_CONTROL:
            USBMIDI_NoDataControlStatusStage();
            break;
        default:    /* there are no more states */
            break;
    }
}


/*******************************************************************************
* Function Name: USBMIDI_HandleOUT
********************************************************************************
*
* Summary:
*  This routine handles EP0 OUT transfers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_HandleOUT(void) 
{
    switch (USBMIDI_transferState)
    {
        case USBMIDI_TRANS_STATE_IDLE:
            break;
        case USBMIDI_TRANS_STATE_CONTROL_READ:
            USBMIDI_ControlReadStatusStage();
            break;
        case USBMIDI_TRANS_STATE_CONTROL_WRITE:
            USBMIDI_ControlWriteDataStage();
            break;
        case USBMIDI_TRANS_STATE_NO_DATA_CONTROL:
            /* Update the completion block */
            USBMIDI_UpdateStatusBlock(USBMIDI_XFER_ERROR);
            /* We expect no more data, so stall INs and OUTs */
            USBMIDI_ep0Mode = USBMIDI_MODE_STALL_IN_OUT;
            break;
        default:    /* There are no more states */
            break;
    }
}


/*******************************************************************************
* Function Name: USBMIDI_LoadEP0
********************************************************************************
*
* Summary:
*  This routine loads the EP0 data registers for OUT transfers.  It uses the
*  currentTD (previously initialized by the _InitControlWrite function and
*  updated for each OUT transfer, and the bLastPacketSize) to determine how
*  many uint8s to transfer on the current OUT.
*
*  If the number of uint8s remaining is zero and the last transfer was full,
*  we need to send a zero length packet.  Otherwise we send the minimum
*  of the control endpoint size (8) or remaining number of uint8s for the
*  transaction.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  USBMIDI_transferByteCount - Update the transfer byte count from the
*     last transaction.
*  USBMIDI_ep0Count - counts the data loaded to the SIE memory in
*     current packet.
*  USBMIDI_lastPacketSize - remembers the USBFS_ep0Count value for the
*     next packet.
*  USBMIDI_transferByteCount - sum of the previous bytes transferred
*     on previous packets(sum of USBFS_lastPacketSize)
*  USBMIDI_ep0Toggle - inverted
*  USBMIDI_ep0Mode  - prepare for mode register content.
*  USBMIDI_transferState - set to TRANS_STATE_CONTROL_READ
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_LoadEP0(void) 
{
    uint8 ep0Count = 0u;

    /* Update the transfer byte count from the last transaction */
    USBMIDI_transferByteCount += USBMIDI_lastPacketSize;
    /* Now load the next transaction */
    while ((USBMIDI_currentTD.count > 0u) && (ep0Count < 8u))
    {
        CY_SET_REG8((reg8 *)(USBMIDI_EP0_DR0_IND + ep0Count), *USBMIDI_currentTD.pData);
        USBMIDI_currentTD.pData = &USBMIDI_currentTD.pData[1u];
        ep0Count++;
        USBMIDI_currentTD.count--;
    }
    /* Support zero-length packet*/
    if( (USBMIDI_lastPacketSize == 8u) || (ep0Count > 0u) )
    {
        /* Update the data toggle */
        USBMIDI_ep0Toggle ^= USBMIDI_EP0_CNT_DATA_TOGGLE;
        /* Set the Mode Register  */
        USBMIDI_ep0Mode = USBMIDI_MODE_ACK_IN_STATUS_OUT;
        /* Update the state (or stay the same) */
        USBMIDI_transferState = USBMIDI_TRANS_STATE_CONTROL_READ;
    }
    else
    {
        /* Expect Status Stage Out */
        USBMIDI_ep0Mode = USBMIDI_MODE_STATUS_OUT_ONLY;
        /* Update the state (or stay the same) */
        USBMIDI_transferState = USBMIDI_TRANS_STATE_CONTROL_READ;
    }

    /* Save the packet size for next time */
    USBMIDI_lastPacketSize = ep0Count;
    USBMIDI_ep0Count = ep0Count;
}


/*******************************************************************************
* Function Name: USBMIDI_InitControlRead
********************************************************************************
*
* Summary:
*  Initialize a control read transaction, usable to send data to the host.
*  The following global variables should be initialized before this function
*  called. To send zero length packet use InitZeroLengthControlTransfer
*  function.
*
* Parameters:
*  None.
*
* Return:
*  requestHandled state.
*
* Global variables:
*  USBMIDI_currentTD.count - counts of data to be sent.
*  USBMIDI_currentTD.pData - data pointer.
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 USBMIDI_InitControlRead(void) 
{
    uint16 xferCount;
    if(USBMIDI_currentTD.count == 0u)
    {
        (void) USBMIDI_InitZeroLengthControlTransfer();
    }
    else
    {
        /* Set up the state machine */
        USBMIDI_transferState = USBMIDI_TRANS_STATE_CONTROL_READ;
        /* Set the toggle, it gets updated in LoadEP */
        USBMIDI_ep0Toggle = 0u;
        /* Initialize the Status Block */
        USBMIDI_InitializeStatusBlock();
        xferCount = (((uint16)CY_GET_REG8(USBMIDI_lengthHi) << 8u) | (CY_GET_REG8(USBMIDI_lengthLo)));

        if (USBMIDI_currentTD.count > xferCount)
        {
            USBMIDI_currentTD.count = xferCount;
        }
        USBMIDI_LoadEP0();
    }

    return(USBMIDI_TRUE);
}


/*******************************************************************************
* Function Name: USBMIDI_InitZeroLengthControlTransfer
********************************************************************************
*
* Summary:
*  Initialize a zero length data IN transfer.
*
* Parameters:
*  None.
*
* Return:
*  requestHandled state.
*
* Global variables:
*  USBMIDI_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*  USBMIDI_ep0Mode  - prepare for mode register content.
*  USBMIDI_transferState - set to TRANS_STATE_CONTROL_READ
*  USBMIDI_ep0Count - cleared, means the zero-length packet.
*  USBMIDI_lastPacketSize - cleared.
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 USBMIDI_InitZeroLengthControlTransfer(void)
                                                
{
    /* Update the state */
    USBMIDI_transferState = USBMIDI_TRANS_STATE_CONTROL_READ;
    /* Set the data toggle */
    USBMIDI_ep0Toggle = USBMIDI_EP0_CNT_DATA_TOGGLE;
    /* Set the Mode Register  */
    USBMIDI_ep0Mode = USBMIDI_MODE_ACK_IN_STATUS_OUT;
    /* Save the packet size for next time */
    USBMIDI_lastPacketSize = 0u;
    USBMIDI_ep0Count = 0u;

    return(USBMIDI_TRUE);
}


/*******************************************************************************
* Function Name: USBMIDI_ControlReadDataStage
********************************************************************************
*
* Summary:
*  Handle the Data Stage of a control read transfer.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_ControlReadDataStage(void) 

{
    USBMIDI_LoadEP0();
}


/*******************************************************************************
* Function Name: USBMIDI_ControlReadStatusStage
********************************************************************************
*
* Summary:
*  Handle the Status Stage of a control read transfer.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  USBMIDI_USBFS_transferByteCount - updated with last packet size.
*  USBMIDI_transferState - set to TRANS_STATE_IDLE.
*  USBMIDI_ep0Mode  - set to MODE_STALL_IN_OUT.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_ControlReadStatusStage(void) 
{
    /* Update the transfer byte count */
    USBMIDI_transferByteCount += USBMIDI_lastPacketSize;
    /* Go Idle */
    USBMIDI_transferState = USBMIDI_TRANS_STATE_IDLE;
    /* Update the completion block */
    USBMIDI_UpdateStatusBlock(USBMIDI_XFER_STATUS_ACK);
    /* We expect no more data, so stall INs and OUTs */
    USBMIDI_ep0Mode =  USBMIDI_MODE_STALL_IN_OUT;
}


/*******************************************************************************
* Function Name: USBMIDI_InitControlWrite
********************************************************************************
*
* Summary:
*  Initialize a control write transaction
*
* Parameters:
*  None.
*
* Return:
*  requestHandled state.
*
* Global variables:
*  USBMIDI_USBFS_transferState - set to TRANS_STATE_CONTROL_WRITE
*  USBMIDI_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*  USBMIDI_ep0Mode  - set to MODE_ACK_OUT_STATUS_IN
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 USBMIDI_InitControlWrite(void) 
{
    uint16 xferCount;

    /* Set up the state machine */
    USBMIDI_transferState = USBMIDI_TRANS_STATE_CONTROL_WRITE;
    /* This might not be necessary */
    USBMIDI_ep0Toggle = USBMIDI_EP0_CNT_DATA_TOGGLE;
    /* Initialize the Status Block */
    USBMIDI_InitializeStatusBlock();

    xferCount = (((uint16)CY_GET_REG8(USBMIDI_lengthHi) << 8u) | (CY_GET_REG8(USBMIDI_lengthLo)));

    if (USBMIDI_currentTD.count > xferCount)
    {
        USBMIDI_currentTD.count = xferCount;
    }

    /* Expect Data or Status Stage */
    USBMIDI_ep0Mode = USBMIDI_MODE_ACK_OUT_STATUS_IN;

    return(USBMIDI_TRUE);
}


/*******************************************************************************
* Function Name: USBMIDI_ControlWriteDataStage
********************************************************************************
*
* Summary:
*  Handle the Data Stage of a control write transfer
*       1. Get the data (We assume the destination was validated previously)
*       2. Update the count and data toggle
*       3. Update the mode register for the next transaction
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  USBMIDI_transferByteCount - Update the transfer byte count from the
*    last transaction.
*  USBMIDI_ep0Count - counts the data loaded from the SIE memory
*    in current packet.
*  USBMIDI_transferByteCount - sum of the previous bytes transferred
*    on previous packets(sum of USBFS_lastPacketSize)
*  USBMIDI_ep0Toggle - inverted
*  USBMIDI_ep0Mode  - set to MODE_ACK_OUT_STATUS_IN.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_ControlWriteDataStage(void) 
{
    uint8 ep0Count;
    uint8 regIndex = 0u;

    ep0Count = (CY_GET_REG8(USBMIDI_EP0_CNT_PTR) & USBMIDI_EPX_CNT0_MASK) -
               USBMIDI_EPX_CNTX_CRC_COUNT;

    USBMIDI_transferByteCount += ep0Count;

    while ((USBMIDI_currentTD.count > 0u) && (ep0Count > 0u))
    {
        *USBMIDI_currentTD.pData = CY_GET_REG8((reg8 *)(USBMIDI_EP0_DR0_IND + regIndex));
        USBMIDI_currentTD.pData = &USBMIDI_currentTD.pData[1u];
        regIndex++;
        ep0Count--;
        USBMIDI_currentTD.count--;
    }
    USBMIDI_ep0Count = ep0Count;
    /* Update the data toggle */
    USBMIDI_ep0Toggle ^= USBMIDI_EP0_CNT_DATA_TOGGLE;
    /* Expect Data or Status Stage */
    USBMIDI_ep0Mode = USBMIDI_MODE_ACK_OUT_STATUS_IN;
}


/*******************************************************************************
* Function Name: USBMIDI_ControlWriteStatusStage
********************************************************************************
*
* Summary:
*  Handle the Status Stage of a control write transfer
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  USBMIDI_transferState - set to TRANS_STATE_IDLE.
*  USBMIDI_USBFS_ep0Mode  - set to MODE_STALL_IN_OUT.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_ControlWriteStatusStage(void) 
{
    /* Go Idle */
    USBMIDI_transferState = USBMIDI_TRANS_STATE_IDLE;
    /* Update the completion block */
    USBMIDI_UpdateStatusBlock(USBMIDI_XFER_STATUS_ACK);
    /* We expect no more data, so stall INs and OUTs */
    USBMIDI_ep0Mode = USBMIDI_MODE_STALL_IN_OUT;
}


/*******************************************************************************
* Function Name: USBMIDI_InitNoDataControlTransfer
********************************************************************************
*
* Summary:
*  Initialize a no data control transfer
*
* Parameters:
*  None.
*
* Return:
*  requestHandled state.
*
* Global variables:
*  USBMIDI_transferState - set to TRANS_STATE_NO_DATA_CONTROL.
*  USBMIDI_ep0Mode  - set to MODE_STATUS_IN_ONLY.
*  USBMIDI_ep0Count - cleared.
*  USBMIDI_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 USBMIDI_InitNoDataControlTransfer(void) 
{
    USBMIDI_transferState = USBMIDI_TRANS_STATE_NO_DATA_CONTROL;
    USBMIDI_ep0Mode = USBMIDI_MODE_STATUS_IN_ONLY;
    USBMIDI_ep0Toggle = USBMIDI_EP0_CNT_DATA_TOGGLE;
    USBMIDI_ep0Count = 0u;

    return(USBMIDI_TRUE);
}


/*******************************************************************************
* Function Name: USBMIDI_NoDataControlStatusStage
********************************************************************************
* Summary:
*  Handle the Status Stage of a no data control transfer.
*
*  SET_ADDRESS is special, since we need to receive the status stage with
*  the old address.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  USBMIDI_transferState - set to TRANS_STATE_IDLE.
*  USBMIDI_ep0Mode  - set to MODE_STALL_IN_OUT.
*  USBMIDI_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*  USBMIDI_deviceAddress - used to set new address and cleared
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_NoDataControlStatusStage(void) 
{
    /* Change the USB address register if we got a SET_ADDRESS. */
    if (USBMIDI_deviceAddress != 0u)
    {
        CY_SET_REG8(USBMIDI_CR0_PTR, USBMIDI_deviceAddress | USBMIDI_CR0_ENABLE);
        USBMIDI_deviceAddress = 0u;
    }
    /* Go Idle */
    USBMIDI_transferState = USBMIDI_TRANS_STATE_IDLE;
    /* Update the completion block */
    USBMIDI_UpdateStatusBlock(USBMIDI_XFER_STATUS_ACK);
     /* We expect no more data, so stall INs and OUTs */
    USBMIDI_ep0Mode = USBMIDI_MODE_STALL_IN_OUT;
}


/*******************************************************************************
* Function Name: USBMIDI_UpdateStatusBlock
********************************************************************************
*
* Summary:
*  Update the Completion Status Block for a Request.  The block is updated
*  with the completion code the USBMIDI_transferByteCount.  The
*  StatusBlock Pointer is set to NULL.
*
* Parameters:
*  completionCode - status.
*
* Return:
*  None.
*
* Global variables:
*  USBMIDI_currentTD.pStatusBlock->status - updated by the
*    completionCode parameter.
*  USBMIDI_currentTD.pStatusBlock->length - updated.
*  USBMIDI_currentTD.pStatusBlock - cleared.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_UpdateStatusBlock(uint8 completionCode) 
{
    if (USBMIDI_currentTD.pStatusBlock != NULL)
    {
        USBMIDI_currentTD.pStatusBlock->status = completionCode;
        USBMIDI_currentTD.pStatusBlock->length = USBMIDI_transferByteCount;
        USBMIDI_currentTD.pStatusBlock = NULL;
    }
}


/*******************************************************************************
* Function Name: USBMIDI_InitializeStatusBlock
********************************************************************************
*
* Summary:
*  Initialize the Completion Status Block for a Request.  The completion
*  code is set to USB_XFER_IDLE.
*
*  Also, initializes USBMIDI_transferByteCount.  Save some space,
*  this is the only consumer.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  USBMIDI_currentTD.pStatusBlock->status - set to XFER_IDLE.
*  USBMIDI_currentTD.pStatusBlock->length - cleared.
*  USBMIDI_transferByteCount - cleared.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_InitializeStatusBlock(void) 
{
    USBMIDI_transferByteCount = 0u;
    if(USBMIDI_currentTD.pStatusBlock != NULL)
    {
        USBMIDI_currentTD.pStatusBlock->status = USBMIDI_XFER_IDLE;
        USBMIDI_currentTD.pStatusBlock->length = 0u;
    }
}


/* [] END OF FILE */
