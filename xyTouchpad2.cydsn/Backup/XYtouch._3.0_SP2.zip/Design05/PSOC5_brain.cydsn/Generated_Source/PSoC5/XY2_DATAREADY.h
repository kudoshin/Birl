/*******************************************************************************
* File Name: XY2_DATAREADY.h  
* Version 2.5
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_XY2_DATAREADY_H) /* Pins XY2_DATAREADY_H */
#define CY_PINS_XY2_DATAREADY_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "XY2_DATAREADY_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_5 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 XY2_DATAREADY__PORT == 15 && ((XY2_DATAREADY__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    XY2_DATAREADY_Write(uint8 value) ;
void    XY2_DATAREADY_SetDriveMode(uint8 mode) ;
uint8   XY2_DATAREADY_ReadDataReg(void) ;
uint8   XY2_DATAREADY_Read(void) ;
uint8   XY2_DATAREADY_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define XY2_DATAREADY_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define XY2_DATAREADY_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define XY2_DATAREADY_DM_RES_UP          PIN_DM_RES_UP
#define XY2_DATAREADY_DM_RES_DWN         PIN_DM_RES_DWN
#define XY2_DATAREADY_DM_OD_LO           PIN_DM_OD_LO
#define XY2_DATAREADY_DM_OD_HI           PIN_DM_OD_HI
#define XY2_DATAREADY_DM_STRONG          PIN_DM_STRONG
#define XY2_DATAREADY_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define XY2_DATAREADY_MASK               XY2_DATAREADY__MASK
#define XY2_DATAREADY_SHIFT              XY2_DATAREADY__SHIFT
#define XY2_DATAREADY_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define XY2_DATAREADY_PS                     (* (reg8 *) XY2_DATAREADY__PS)
/* Data Register */
#define XY2_DATAREADY_DR                     (* (reg8 *) XY2_DATAREADY__DR)
/* Port Number */
#define XY2_DATAREADY_PRT_NUM                (* (reg8 *) XY2_DATAREADY__PRT) 
/* Connect to Analog Globals */                                                  
#define XY2_DATAREADY_AG                     (* (reg8 *) XY2_DATAREADY__AG)                       
/* Analog MUX bux enable */
#define XY2_DATAREADY_AMUX                   (* (reg8 *) XY2_DATAREADY__AMUX) 
/* Bidirectional Enable */                                                        
#define XY2_DATAREADY_BIE                    (* (reg8 *) XY2_DATAREADY__BIE)
/* Bit-mask for Aliased Register Access */
#define XY2_DATAREADY_BIT_MASK               (* (reg8 *) XY2_DATAREADY__BIT_MASK)
/* Bypass Enable */
#define XY2_DATAREADY_BYP                    (* (reg8 *) XY2_DATAREADY__BYP)
/* Port wide control signals */                                                   
#define XY2_DATAREADY_CTL                    (* (reg8 *) XY2_DATAREADY__CTL)
/* Drive Modes */
#define XY2_DATAREADY_DM0                    (* (reg8 *) XY2_DATAREADY__DM0) 
#define XY2_DATAREADY_DM1                    (* (reg8 *) XY2_DATAREADY__DM1)
#define XY2_DATAREADY_DM2                    (* (reg8 *) XY2_DATAREADY__DM2) 
/* Input Buffer Disable Override */
#define XY2_DATAREADY_INP_DIS                (* (reg8 *) XY2_DATAREADY__INP_DIS)
/* LCD Common or Segment Drive */
#define XY2_DATAREADY_LCD_COM_SEG            (* (reg8 *) XY2_DATAREADY__LCD_COM_SEG)
/* Enable Segment LCD */
#define XY2_DATAREADY_LCD_EN                 (* (reg8 *) XY2_DATAREADY__LCD_EN)
/* Slew Rate Control */
#define XY2_DATAREADY_SLW                    (* (reg8 *) XY2_DATAREADY__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define XY2_DATAREADY_PRTDSI__CAPS_SEL       (* (reg8 *) XY2_DATAREADY__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define XY2_DATAREADY_PRTDSI__DBL_SYNC_IN    (* (reg8 *) XY2_DATAREADY__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define XY2_DATAREADY_PRTDSI__OE_SEL0        (* (reg8 *) XY2_DATAREADY__PRTDSI__OE_SEL0) 
#define XY2_DATAREADY_PRTDSI__OE_SEL1        (* (reg8 *) XY2_DATAREADY__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define XY2_DATAREADY_PRTDSI__OUT_SEL0       (* (reg8 *) XY2_DATAREADY__PRTDSI__OUT_SEL0) 
#define XY2_DATAREADY_PRTDSI__OUT_SEL1       (* (reg8 *) XY2_DATAREADY__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define XY2_DATAREADY_PRTDSI__SYNC_OUT       (* (reg8 *) XY2_DATAREADY__PRTDSI__SYNC_OUT) 


#if defined(XY2_DATAREADY__INTSTAT)  /* Interrupt Registers */

    #define XY2_DATAREADY_INTSTAT                (* (reg8 *) XY2_DATAREADY__INTSTAT)
    #define XY2_DATAREADY_SNAP                   (* (reg8 *) XY2_DATAREADY__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_XY2_DATAREADY_H */


/* [] END OF FILE */
