/*******************************************************************************
* File Name: USBMIDI_audio.c
* Version 2.70
*
* Description:
*  USB AUDIO Class request handler.
*
* Related Document:
*  Universal Serial Bus Device Class Definition for Audio Devices Release 1.0
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "USBMIDI.h"

#if defined(USBMIDI_ENABLE_AUDIO_CLASS)

#include "USBMIDI_audio.h"
#include "USBMIDI_pvt.h"
#if defined(USBMIDI_ENABLE_MIDI_STREAMING)
    #include "USBMIDI_midi.h"
#endif /*  USBMIDI_ENABLE_MIDI_STREAMING*/


/***************************************
* Custom Declarations
***************************************/

/* `#START CUSTOM_DECLARATIONS` Place your declaration here */

/* `#END` */


#if !defined(USER_SUPPLIED_AUDIO_HANDLER)


/***************************************
*    AUDIO Variables
***************************************/

#if defined(USBMIDI_ENABLE_AUDIO_STREAMING)
    volatile uint8 USBMIDI_currentSampleFrequency[USBMIDI_MAX_EP][USBMIDI_SAMPLE_FREQ_LEN];
    volatile uint8 USBMIDI_frequencyChanged;
    volatile uint8 USBMIDI_currentMute;
    volatile uint8 USBMIDI_currentVolume[USBMIDI_VOLUME_LEN];
    volatile uint8 USBMIDI_minimumVolume[USBMIDI_VOLUME_LEN] = {USBMIDI_VOL_MIN_LSB,
                                                                                  USBMIDI_VOL_MIN_MSB};
    volatile uint8 USBMIDI_maximumVolume[USBMIDI_VOLUME_LEN] = {USBMIDI_VOL_MAX_LSB,
                                                                                  USBMIDI_VOL_MAX_MSB};
    volatile uint8 USBMIDI_resolutionVolume[USBMIDI_VOLUME_LEN] = {USBMIDI_VOL_RES_LSB,
                                                                                     USBMIDI_VOL_RES_MSB};
#endif /*  USBMIDI_ENABLE_AUDIO_STREAMING */


/*******************************************************************************
* Function Name: USBMIDI_DispatchAUDIOClassRqst
********************************************************************************
*
* Summary:
*  This routine dispatches class requests
*
* Parameters:
*  None.
*
* Return:
*  requestHandled
*
* Global variables:
*   USBMIDI_currentSampleFrequency: Contains the current audio Sample
*       Frequency. It is set by the Host using SET_CUR request to the endpoint.
*   USBMIDI_frequencyChanged: This variable is used as a flag for the
*       user code, to be aware that Host has been sent request for changing
*       Sample Frequency. Sample frequency will be sent on the next OUT
*       transaction. It is contains endpoint address when set. The following
*       code is recommended for detecting new Sample Frequency in main code:
*       if((USBMIDI_frequencyChanged != 0) &&
*       (USBMIDI_transferState == USBMIDI_TRANS_STATE_IDLE))
*       {
*          USBMIDI_frequencyChanged = 0;
*       }
*       USBMIDI_transferState variable is checked to be sure that
*             transfer completes.
*   USBMIDI_currentMute: Contains mute configuration set by Host.
*   USBMIDI_currentVolume: Contains volume level set by Host.
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 USBMIDI_DispatchAUDIOClassRqst(void) 
{
    uint8 requestHandled = USBMIDI_FALSE;
    uint8 bmRequestType  = CY_GET_REG8(USBMIDI_bmRequestType);
    
    #if defined(USBMIDI_ENABLE_AUDIO_STREAMING)
        uint8 epNumber;
        epNumber = CY_GET_REG8(USBMIDI_wIndexLo) & USBMIDI_DIR_UNUSED;
    #endif /*  USBMIDI_ENABLE_AUDIO_STREAMING */
    

    if ((bmRequestType & USBMIDI_RQST_DIR_MASK) == USBMIDI_RQST_DIR_D2H)
    {
        /* Control Read */
        if((bmRequestType & USBMIDI_RQST_RCPT_MASK) == USBMIDI_RQST_RCPT_EP)
        {
            /* Endpoint */
            switch (CY_GET_REG8(USBMIDI_bRequest))
            {
                case USBMIDI_GET_CUR:
                #if defined(USBMIDI_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_SAMPLING_FREQ_CONTROL)
                    {
                         /* point Control Selector is Sampling Frequency */
                        USBMIDI_currentTD.wCount = USBMIDI_SAMPLE_FREQ_LEN;
                        USBMIDI_currentTD.pData  = USBMIDI_currentSampleFrequency[epNumber];
                        requestHandled   = USBMIDI_InitControlRead();
                    }
                #endif /*  USBMIDI_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_READ_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else if((bmRequestType & USBMIDI_RQST_RCPT_MASK) == USBMIDI_RQST_RCPT_IFC)
        {
            /* Interface or Entity ID */
            switch (CY_GET_REG8(USBMIDI_bRequest))
            {
                case USBMIDI_GET_CUR:
                #if defined(USBMIDI_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_MUTE_CONTROL)
                    {
                        /* `#START MUTE_CONTROL_GET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                         /* Entity ID Control Selector is MUTE */
                        USBMIDI_currentTD.wCount = 1u;
                        USBMIDI_currentTD.pData  = &USBMIDI_currentMute;
                        requestHandled   = USBMIDI_InitControlRead();
                    }
                    else if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_VOLUME_CONTROL)
                    {
                        /* `#START VOLUME_CONTROL_GET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                        /* Entity ID Control Selector is VOLUME, */
                        USBMIDI_currentTD.wCount = USBMIDI_VOLUME_LEN;
                        USBMIDI_currentTD.pData  = USBMIDI_currentVolume;
                        requestHandled   = USBMIDI_InitControlRead();
                    }
                    else
                    {
                        /* `#START OTHER_GET_CUR_REQUESTS` Place other request handler here */

                        /* `#END` */
                    }
                    break;
                case USBMIDI_GET_MIN:    /* GET_MIN */
                    if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_VOLUME_CONTROL)
                    {
                        /* Entity ID Control Selector is VOLUME, */
                        USBMIDI_currentTD.wCount = USBMIDI_VOLUME_LEN;
                        USBMIDI_currentTD.pData  = &USBMIDI_minimumVolume[0];
                        requestHandled   = USBMIDI_InitControlRead();
                    }
                    break;
                case USBMIDI_GET_MAX:    /* GET_MAX */
                    if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_VOLUME_CONTROL)
                    {
                        /* Entity ID Control Selector is VOLUME, */
                        USBMIDI_currentTD.wCount = USBMIDI_VOLUME_LEN;
                        USBMIDI_currentTD.pData  = &USBMIDI_maximumVolume[0];
                        requestHandled   = USBMIDI_InitControlRead();
                    }
                    break;
                case USBMIDI_GET_RES:    /* GET_RES */
                    if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_VOLUME_CONTROL)
                    {
                         /* Entity ID Control Selector is VOLUME, */
                        USBMIDI_currentTD.wCount = USBMIDI_VOLUME_LEN;
                        USBMIDI_currentTD.pData  = &USBMIDI_resolutionVolume[0];
                        requestHandled   = USBMIDI_InitControlRead();
                    }
                    break;
                /* The contents of the status message is reserved for future use.
                *  For the time being, a null packet should be returned in the data stage of the
                *  control transfer, and the received null packet should be ACKed.
                */
                case USBMIDI_GET_STAT:
                        USBMIDI_currentTD.wCount = 0u;
                        requestHandled   = USBMIDI_InitControlWrite();

                #endif /*  USBMIDI_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_WRITE_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else
        {   /* USBMIDI_RQST_RCPT_OTHER */
        }
    }
    else if ((bmRequestType & USBMIDI_RQST_DIR_MASK) == USBMIDI_RQST_DIR_H2D)
    {
        /* Control Write */
        if((bmRequestType & USBMIDI_RQST_RCPT_MASK) == USBMIDI_RQST_RCPT_EP)
        {
            /* point */
            switch (CY_GET_REG8(USBMIDI_bRequest))
            {
                case USBMIDI_SET_CUR:
                #if defined(USBMIDI_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_SAMPLING_FREQ_CONTROL)
                    {
                         /* point Control Selector is Sampling Frequency */
                        USBMIDI_currentTD.wCount = USBMIDI_SAMPLE_FREQ_LEN;
                        USBMIDI_currentTD.pData  = USBMIDI_currentSampleFrequency[epNumber];
                        requestHandled   = USBMIDI_InitControlWrite();
                        USBMIDI_frequencyChanged = epNumber;
                    }
                #endif /*  USBMIDI_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_SAMPLING_FREQ_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else if((bmRequestType & USBMIDI_RQST_RCPT_MASK) == USBMIDI_RQST_RCPT_IFC)
        {
            /* Interface or Entity ID */
            switch (CY_GET_REG8(USBMIDI_bRequest))
            {
                case USBMIDI_SET_CUR:
                #if defined(USBMIDI_ENABLE_AUDIO_STREAMING)
                    if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_MUTE_CONTROL)
                    {
                        /* `#START MUTE_SET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                        /* Entity ID Control Selector is MUTE */
                        USBMIDI_currentTD.wCount = 1u;
                        USBMIDI_currentTD.pData  = &USBMIDI_currentMute;
                        requestHandled   = USBMIDI_InitControlWrite();
                    }
                    else if(CY_GET_REG8(USBMIDI_wValueHi) == USBMIDI_VOLUME_CONTROL)
                    {
                        /* `#START VOLUME_CONTROL_SET_REQUEST` Place multi-channel handler here */

                        /* `#END` */

                        /* Entity ID Control Selector is VOLUME */
                        USBMIDI_currentTD.wCount = USBMIDI_VOLUME_LEN;
                        USBMIDI_currentTD.pData  = USBMIDI_currentVolume;
                        requestHandled   = USBMIDI_InitControlWrite();
                    }
                    else
                    {
                        /* `#START OTHER_SET_CUR_REQUESTS` Place other request handler here */

                        /* `#END` */
                    }
                #endif /*  USBMIDI_ENABLE_AUDIO_STREAMING */

                /* `#START AUDIO_CONTROL_SEL_REQUESTS` Place other request handler here */

                /* `#END` */
                    break;
                default:
                    break;
            }
        }
        else
        {   
            /* USBMIDI_RQST_RCPT_OTHER */
        }
    }
    else
    {   
        /* requestHandled is initialized as FALSE by default */
    }

    return(requestHandled);
}

#endif /* USER_SUPPLIED_AUDIO_HANDLER */


/*******************************************************************************
* Additional user functions supporting AUDIO Requests
********************************************************************************/

/* `#START AUDIO_FUNCTIONS` Place any additional functions here */

/* `#END` */

#endif  /*  USBMIDI_ENABLE_AUDIO_CLASS */


/* [] END OF FILE */
