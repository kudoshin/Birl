/*******************************************************************************
* File Name: .h
* Version 2.70
*
* Description:
*  This private file provides constants and parameter values for the
*  USBFS Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_USBFS_USBMIDI_1_pvt_H)
#define CY_USBFS_USBMIDI_1_pvt_H


/***************************************
*     Private Variables
***************************************/

/* Generated external references for descriptors*/
extern const uint8 CYCODE USBMIDI_1_DEVICE0_DESCR[18u];
extern const uint8 CYCODE USBMIDI_1_DEVICE0_CONFIGURATION0_DESCR[101u];
extern const T_USBMIDI_1_EP_SETTINGS_BLOCK CYCODE USBMIDI_1_DEVICE0_CONFIGURATION0_EP_SETTINGS_TABLE[2u];
extern const uint8 CYCODE USBMIDI_1_DEVICE0_CONFIGURATION0_INTERFACE_CLASS[2u];
extern const T_USBMIDI_1_LUT CYCODE USBMIDI_1_DEVICE0_CONFIGURATION0_TABLE[5u];
extern const T_USBMIDI_1_LUT CYCODE USBMIDI_1_DEVICE0_TABLE[2u];
extern const T_USBMIDI_1_LUT CYCODE USBMIDI_1_TABLE[1u];
extern const uint8 CYCODE USBMIDI_1_SN_STRING_DESCRIPTOR[2];
extern const uint8 CYCODE USBMIDI_1_STRING_DESCRIPTORS[275u];


extern const uint8 CYCODE USBMIDI_1_MSOS_DESCRIPTOR[USBMIDI_1_MSOS_DESCRIPTOR_LENGTH];
extern const uint8 CYCODE USBMIDI_1_MSOS_CONFIGURATION_DESCR[USBMIDI_1_MSOS_CONF_DESCR_LENGTH];
#if defined(USBMIDI_1_ENABLE_IDSN_STRING)
    extern uint8 USBMIDI_1_idSerialNumberStringDescriptor[USBMIDI_1_IDSN_DESCR_LENGTH];
#endif /* USBMIDI_1_ENABLE_IDSN_STRING */

extern volatile uint8 USBMIDI_1_interfaceNumber;
extern volatile uint8 USBMIDI_1_interfaceSetting[USBMIDI_1_MAX_INTERFACES_NUMBER];
extern volatile uint8 USBMIDI_1_interfaceSetting_last[USBMIDI_1_MAX_INTERFACES_NUMBER];
extern volatile uint8 USBMIDI_1_deviceAddress;
extern volatile uint8 USBMIDI_1_interfaceStatus[USBMIDI_1_MAX_INTERFACES_NUMBER];
extern const uint8 CYCODE *USBMIDI_1_interfaceClass;

extern volatile T_USBMIDI_1_EP_CTL_BLOCK USBMIDI_1_EP[USBMIDI_1_MAX_EP];
extern volatile T_USBMIDI_1_TD USBMIDI_1_currentTD;

#if(USBMIDI_1_EP_MM != USBMIDI_1__EP_MANUAL)
    extern uint8 USBMIDI_1_DmaChan[USBMIDI_1_MAX_EP];
    extern uint8 USBMIDI_1_DmaTd[USBMIDI_1_MAX_EP];
#endif /*  USBMIDI_1_EP_MM */
#if((USBMIDI_1_EP_MM == USBMIDI_1__EP_DMAAUTO) && (USBMIDI_1_EP_DMA_AUTO_OPT == 0u))
    extern uint8 USBMIDI_1_DmaNextTd[USBMIDI_1_MAX_EP];
    extern volatile uint16 USBMIDI_1_inLength[USBMIDI_1_MAX_EP];
    extern const uint8 *USBMIDI_1_inDataPointer[USBMIDI_1_MAX_EP];
    extern volatile uint8 USBMIDI_1_inBufFull[USBMIDI_1_MAX_EP];
#endif /*  ((USBMIDI_1_EP_MM == USBMIDI_1__EP_DMAAUTO) && (USBMIDI_1_EP_DMA_AUTO_OPT == 0u)) */

extern volatile uint8 USBMIDI_1_ep0Toggle;
extern volatile uint8 USBMIDI_1_lastPacketSize;
extern volatile uint8 USBMIDI_1_ep0Mode;
extern volatile uint8 USBMIDI_1_ep0Count;
extern volatile uint16 USBMIDI_1_transferByteCount;


/***************************************
*     Private Function Prototypes
***************************************/
void  USBMIDI_1_ReInitComponent(void) ;
void  USBMIDI_1_HandleSetup(void) ;
void  USBMIDI_1_HandleIN(void) ;
void  USBMIDI_1_HandleOUT(void) ;
void  USBMIDI_1_LoadEP0(void) ;
uint8 USBMIDI_1_InitControlRead(void) ;
uint8 USBMIDI_1_InitControlWrite(void) ;
void  USBMIDI_1_ControlReadDataStage(void) ;
void  USBMIDI_1_ControlReadStatusStage(void) ;
void  USBMIDI_1_ControlReadPrematureStatus(void)
                                                ;
uint8 USBMIDI_1_InitControlWrite(void) ;
uint8 USBMIDI_1_InitZeroLengthControlTransfer(void)
                                                ;
void  USBMIDI_1_ControlWriteDataStage(void) ;
void  USBMIDI_1_ControlWriteStatusStage(void) ;
void  USBMIDI_1_ControlWritePrematureStatus(void)
                                                ;
uint8 USBMIDI_1_InitNoDataControlTransfer(void) ;
void  USBMIDI_1_NoDataControlStatusStage(void) ;
void  USBMIDI_1_InitializeStatusBlock(void) ;
void  USBMIDI_1_UpdateStatusBlock(uint8 completionCode) ;
uint8 USBMIDI_1_DispatchClassRqst(void) ;

void USBMIDI_1_Config(uint8 clearAltSetting) ;
void USBMIDI_1_ConfigAltChanged(void) ;
void USBMIDI_1_ConfigReg(void) ;

const T_USBMIDI_1_LUT CYCODE *USBMIDI_1_GetConfigTablePtr(uint8 confIndex)
                                                            ;
const T_USBMIDI_1_LUT CYCODE *USBMIDI_1_GetDeviceTablePtr(void)
                                                            ;
const uint8 CYCODE *USBMIDI_1_GetInterfaceClassTablePtr(void)
                                                    ;
uint8 USBMIDI_1_ClearEndpointHalt(void) ;
uint8 USBMIDI_1_SetEndpointHalt(void) ;
uint8 USBMIDI_1_ValidateAlternateSetting(void) ;

void USBMIDI_1_SaveConfig(void) ;
void USBMIDI_1_RestoreConfig(void) ;

#if ((USBMIDI_1_EP_MM == USBMIDI_1__EP_DMAAUTO) && (USBMIDI_1_EP_DMA_AUTO_OPT == 0u))
    void USBMIDI_1_LoadNextInEP(uint8 epNumber, uint8 mode) ;
#endif /* (USBMIDI_1_EP_MM == USBMIDI_1__EP_DMAAUTO) && (USBMIDI_1_EP_DMA_AUTO_OPT == 0u) */
    
#if defined(USBMIDI_1_ENABLE_IDSN_STRING)
    void USBMIDI_1_ReadDieID(uint8 descr[]) ;
#endif /* USBMIDI_1_ENABLE_IDSN_STRING */

#if defined(USBMIDI_1_ENABLE_HID_CLASS)
    uint8 USBMIDI_1_DispatchHIDClassRqst(void);
#endif /*  USBMIDI_1_ENABLE_HID_CLASS */
#if defined(USBMIDI_1_ENABLE_AUDIO_CLASS)
    uint8 USBMIDI_1_DispatchAUDIOClassRqst(void);
#endif /*  USBMIDI_1_ENABLE_HID_CLASS */
#if defined(USBMIDI_1_ENABLE_CDC_CLASS)
    uint8 USBMIDI_1_DispatchCDCClassRqst(void);
#endif /*  USBMIDI_1_ENABLE_CDC_CLASS */

CY_ISR_PROTO(USBMIDI_1_EP_0_ISR);
#if(USBMIDI_1_EP1_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_1_ISR);
#endif /*  USBMIDI_1_EP1_ISR_REMOVE */
#if(USBMIDI_1_EP2_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_2_ISR);
#endif /*  USBMIDI_1_EP2_ISR_REMOVE */
#if(USBMIDI_1_EP3_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_3_ISR);
#endif /*  USBMIDI_1_EP3_ISR_REMOVE */
#if(USBMIDI_1_EP4_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_4_ISR);
#endif /*  USBMIDI_1_EP4_ISR_REMOVE */
#if(USBMIDI_1_EP5_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_5_ISR);
#endif /*  USBMIDI_1_EP5_ISR_REMOVE */
#if(USBMIDI_1_EP6_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_6_ISR);
#endif /*  USBMIDI_1_EP6_ISR_REMOVE */
#if(USBMIDI_1_EP7_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_7_ISR);
#endif /*  USBMIDI_1_EP7_ISR_REMOVE */
#if(USBMIDI_1_EP8_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_EP_8_ISR);
#endif /*  USBMIDI_1_EP8_ISR_REMOVE */
CY_ISR_PROTO(USBMIDI_1_BUS_RESET_ISR);
#if(USBMIDI_1_SOF_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_SOF_ISR);
#endif /*  USBMIDI_1_SOF_ISR_REMOVE */
#if(USBMIDI_1_EP_MM != USBMIDI_1__EP_MANUAL)
    CY_ISR_PROTO(USBMIDI_1_ARB_ISR);
#endif /*  USBMIDI_1_EP_MM */
#if(USBMIDI_1_DP_ISR_REMOVE == 0u)
    CY_ISR_PROTO(USBMIDI_1_DP_ISR);
#endif /*  USBMIDI_1_DP_ISR_REMOVE */
#if ((USBMIDI_1_EP_MM == USBMIDI_1__EP_DMAAUTO) && (USBMIDI_1_EP_DMA_AUTO_OPT == 0u))
    CY_ISR_PROTO(USBMIDI_1_EP_DMA_DONE_ISR);
#endif /* (USBMIDI_1_EP_MM == USBMIDI_1__EP_DMAAUTO) && (USBMIDI_1_EP_DMA_AUTO_OPT == 0u) */

/***************************************
* Request Handlers
***************************************/

uint8 USBMIDI_1_HandleStandardRqst(void) ;
uint8 USBMIDI_1_DispatchClassRqst(void) ;
uint8 USBMIDI_1_HandleVendorRqst(void) ;


/***************************************
*    HID Internal references
***************************************/

#if defined(USBMIDI_1_ENABLE_HID_CLASS)
    void USBMIDI_1_FindReport(void) ;
    void USBMIDI_1_FindReportDescriptor(void) ;
    void USBMIDI_1_FindHidClassDecriptor(void) ;
#endif /* USBMIDI_1_ENABLE_HID_CLASS */


/***************************************
*    MIDI Internal references
***************************************/

#if defined(USBMIDI_1_ENABLE_MIDI_STREAMING)
    void USBMIDI_1_MIDI_IN_EP_Service(void) ;
#endif /* USBMIDI_1_ENABLE_MIDI_STREAMING */


#endif /* CY_USBFS_USBMIDI_1_pvt_H */


/* [] END OF FILE */
