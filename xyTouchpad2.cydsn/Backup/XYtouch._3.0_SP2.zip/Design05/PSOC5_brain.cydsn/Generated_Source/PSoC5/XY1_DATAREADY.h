/*******************************************************************************
* File Name: XY1_DATAREADY.h  
* Version 2.5
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_XY1_DATAREADY_H) /* Pins XY1_DATAREADY_H */
#define CY_PINS_XY1_DATAREADY_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "XY1_DATAREADY_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_5 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 XY1_DATAREADY__PORT == 15 && ((XY1_DATAREADY__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    XY1_DATAREADY_Write(uint8 value) ;
void    XY1_DATAREADY_SetDriveMode(uint8 mode) ;
uint8   XY1_DATAREADY_ReadDataReg(void) ;
uint8   XY1_DATAREADY_Read(void) ;
uint8   XY1_DATAREADY_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define XY1_DATAREADY_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define XY1_DATAREADY_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define XY1_DATAREADY_DM_RES_UP          PIN_DM_RES_UP
#define XY1_DATAREADY_DM_RES_DWN         PIN_DM_RES_DWN
#define XY1_DATAREADY_DM_OD_LO           PIN_DM_OD_LO
#define XY1_DATAREADY_DM_OD_HI           PIN_DM_OD_HI
#define XY1_DATAREADY_DM_STRONG          PIN_DM_STRONG
#define XY1_DATAREADY_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define XY1_DATAREADY_MASK               XY1_DATAREADY__MASK
#define XY1_DATAREADY_SHIFT              XY1_DATAREADY__SHIFT
#define XY1_DATAREADY_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define XY1_DATAREADY_PS                     (* (reg8 *) XY1_DATAREADY__PS)
/* Data Register */
#define XY1_DATAREADY_DR                     (* (reg8 *) XY1_DATAREADY__DR)
/* Port Number */
#define XY1_DATAREADY_PRT_NUM                (* (reg8 *) XY1_DATAREADY__PRT) 
/* Connect to Analog Globals */                                                  
#define XY1_DATAREADY_AG                     (* (reg8 *) XY1_DATAREADY__AG)                       
/* Analog MUX bux enable */
#define XY1_DATAREADY_AMUX                   (* (reg8 *) XY1_DATAREADY__AMUX) 
/* Bidirectional Enable */                                                        
#define XY1_DATAREADY_BIE                    (* (reg8 *) XY1_DATAREADY__BIE)
/* Bit-mask for Aliased Register Access */
#define XY1_DATAREADY_BIT_MASK               (* (reg8 *) XY1_DATAREADY__BIT_MASK)
/* Bypass Enable */
#define XY1_DATAREADY_BYP                    (* (reg8 *) XY1_DATAREADY__BYP)
/* Port wide control signals */                                                   
#define XY1_DATAREADY_CTL                    (* (reg8 *) XY1_DATAREADY__CTL)
/* Drive Modes */
#define XY1_DATAREADY_DM0                    (* (reg8 *) XY1_DATAREADY__DM0) 
#define XY1_DATAREADY_DM1                    (* (reg8 *) XY1_DATAREADY__DM1)
#define XY1_DATAREADY_DM2                    (* (reg8 *) XY1_DATAREADY__DM2) 
/* Input Buffer Disable Override */
#define XY1_DATAREADY_INP_DIS                (* (reg8 *) XY1_DATAREADY__INP_DIS)
/* LCD Common or Segment Drive */
#define XY1_DATAREADY_LCD_COM_SEG            (* (reg8 *) XY1_DATAREADY__LCD_COM_SEG)
/* Enable Segment LCD */
#define XY1_DATAREADY_LCD_EN                 (* (reg8 *) XY1_DATAREADY__LCD_EN)
/* Slew Rate Control */
#define XY1_DATAREADY_SLW                    (* (reg8 *) XY1_DATAREADY__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define XY1_DATAREADY_PRTDSI__CAPS_SEL       (* (reg8 *) XY1_DATAREADY__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define XY1_DATAREADY_PRTDSI__DBL_SYNC_IN    (* (reg8 *) XY1_DATAREADY__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define XY1_DATAREADY_PRTDSI__OE_SEL0        (* (reg8 *) XY1_DATAREADY__PRTDSI__OE_SEL0) 
#define XY1_DATAREADY_PRTDSI__OE_SEL1        (* (reg8 *) XY1_DATAREADY__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define XY1_DATAREADY_PRTDSI__OUT_SEL0       (* (reg8 *) XY1_DATAREADY__PRTDSI__OUT_SEL0) 
#define XY1_DATAREADY_PRTDSI__OUT_SEL1       (* (reg8 *) XY1_DATAREADY__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define XY1_DATAREADY_PRTDSI__SYNC_OUT       (* (reg8 *) XY1_DATAREADY__PRTDSI__SYNC_OUT) 


#if defined(XY1_DATAREADY__INTSTAT)  /* Interrupt Registers */

    #define XY1_DATAREADY_INTSTAT                (* (reg8 *) XY1_DATAREADY__INTSTAT)
    #define XY1_DATAREADY_SNAP                   (* (reg8 *) XY1_DATAREADY__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_XY1_DATAREADY_H */


/* [] END OF FILE */
