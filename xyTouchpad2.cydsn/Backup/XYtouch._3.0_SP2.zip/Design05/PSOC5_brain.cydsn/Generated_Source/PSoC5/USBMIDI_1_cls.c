/*******************************************************************************
* File Name: USBMIDI_1_cls.c
* Version 2.70
*
* Description:
*  USB Class request handler.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "USBMIDI_1.h"

#if(USBMIDI_1_EXTERN_CLS == USBMIDI_1_FALSE)

#include "USBMIDI_1_pvt.h"


/***************************************
* User Implemented Class Driver Declarations.
***************************************/
/* `#START USER_DEFINED_CLASS_DECLARATIONS` Place your declaration here */

/* `#END` */


/*******************************************************************************
* Function Name: USBMIDI_1_DispatchClassRqst
********************************************************************************
* Summary:
*  This routine dispatches class specific requests depend on interface class.
*
* Parameters:
*  None.
*
* Return:
*  requestHandled.
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 USBMIDI_1_DispatchClassRqst(void) 
{
    uint8 requestHandled = USBMIDI_1_FALSE;
    uint8 interfaceNumber = 0u;

    switch(CY_GET_REG8(USBMIDI_1_bmRequestType) & USBMIDI_1_RQST_RCPT_MASK)
    {
        case USBMIDI_1_RQST_RCPT_IFC:        /* Class-specific request directed to an interface */
            interfaceNumber = CY_GET_REG8(USBMIDI_1_wIndexLo); /* wIndexLo contain Interface number */
            break;
        case USBMIDI_1_RQST_RCPT_EP:         /* Class-specific request directed to the endpoint */
            /* Find related interface to the endpoint, wIndexLo contain EP number */
            interfaceNumber = USBMIDI_1_EP[CY_GET_REG8(USBMIDI_1_wIndexLo) & 
                              USBMIDI_1_DIR_UNUSED].interface;
            break;
        default:    /* RequestHandled is initialized as FALSE by default */
            break;
    }
    /* Handle Class request depend on interface type */
    switch(USBMIDI_1_interfaceClass[interfaceNumber])
    {
        case USBMIDI_1_CLASS_HID:
            #if defined(USBMIDI_1_ENABLE_HID_CLASS)
                requestHandled = USBMIDI_1_DispatchHIDClassRqst();
            #endif /* USBMIDI_1_ENABLE_HID_CLASS */
            break;
        case USBMIDI_1_CLASS_AUDIO:
            #if defined(USBMIDI_1_ENABLE_AUDIO_CLASS)
                requestHandled = USBMIDI_1_DispatchAUDIOClassRqst();
            #endif /* USBMIDI_1_CLASS_AUDIO */
            break;
        case USBMIDI_1_CLASS_CDC:
            #if defined(USBMIDI_1_ENABLE_CDC_CLASS)
                requestHandled = USBMIDI_1_DispatchCDCClassRqst();
            #endif /* USBMIDI_1_ENABLE_CDC_CLASS */
            break;
        default:    /* requestHandled is initialized as FALSE by default */
            break;
    }

    /* `#START USER_DEFINED_CLASS_CODE` Place your Class request here */

    /* `#END` */

    return(requestHandled);
}


/*******************************************************************************
* Additional user functions supporting Class Specific Requests
********************************************************************************/

/* `#START CLASS_SPECIFIC_FUNCTIONS` Place any additional functions here */

/* `#END` */

#endif /* USBMIDI_1_EXTERN_CLS */


/* [] END OF FILE */
