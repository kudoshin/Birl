/*******************************************************************************
* File Name: USBMIDI.c
* Version 2.70
*
* Description:
*  API for USBFS Component.
*
* Note:
*  Many of the functions use endpoint number.  RAM arrays are sized with 9
*  elements so they are indexed directly by epNumber.  The SIE and ARB
*  registers are indexed by variations of epNumber - 1.
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include <CyDmac.h>
#include "USBMIDI.h"
#include "USBMIDI_pvt.h"
#include "USBMIDI_hid.h"
#if(USBMIDI_DMA1_REMOVE == 0u)
    #include "USBMIDI_ep1_dma.h"
#endif   /*  USBMIDI_DMA1_REMOVE */
#if(USBMIDI_DMA2_REMOVE == 0u)
    #include "USBMIDI_ep2_dma.h"
#endif   /*  USBMIDI_DMA2_REMOVE */
#if(USBMIDI_DMA3_REMOVE == 0u)
    #include "USBMIDI_ep3_dma.h"
#endif   /*  USBMIDI_DMA3_REMOVE */
#if(USBMIDI_DMA4_REMOVE == 0u)
    #include "USBMIDI_ep4_dma.h"
#endif   /*  USBMIDI_DMA4_REMOVE */
#if(USBMIDI_DMA5_REMOVE == 0u)
    #include "USBMIDI_ep5_dma.h"
#endif   /*  USBMIDI_DMA5_REMOVE */
#if(USBMIDI_DMA6_REMOVE == 0u)
    #include "USBMIDI_ep6_dma.h"
#endif   /*  USBMIDI_DMA6_REMOVE */
#if(USBMIDI_DMA7_REMOVE == 0u)
    #include "USBMIDI_ep7_dma.h"
#endif   /*  USBMIDI_DMA7_REMOVE */
#if(USBMIDI_DMA8_REMOVE == 0u)
    #include "USBMIDI_ep8_dma.h"
#endif   /*  USBMIDI_DMA8_REMOVE */
#if((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u))
    #include "USBMIDI_EP_DMA_Done_isr.h"
    #include "USBMIDI_EP8_DMA_Done_SR.h"
    #include "USBMIDI_EP17_DMA_Done_SR.h"
#endif /* ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u)) */


/***************************************
* Global data allocation
***************************************/

uint8 USBMIDI_initVar = 0u;
#if(USBMIDI_EP_MM != USBMIDI__EP_MANUAL)
    uint8 USBMIDI_DmaChan[USBMIDI_MAX_EP];
    uint8 USBMIDI_DmaTd[USBMIDI_MAX_EP];
#endif /*  USBMIDI_EP_MM */
#if((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u))
    static uint8 clearInDataRdyStatus = USBMIDI_ARB_EPX_CFG_DEFAULT;
    uint8 USBMIDI_DmaNextTd[USBMIDI_MAX_EP];
    const uint8 USBMIDI_epX_TD_TERMOUT_EN[USBMIDI_MAX_EP] =
    {   0u,
        USBMIDI_ep1_TD_TERMOUT_EN,
        USBMIDI_ep2_TD_TERMOUT_EN,
        USBMIDI_ep3_TD_TERMOUT_EN,
        USBMIDI_ep4_TD_TERMOUT_EN,
        USBMIDI_ep5_TD_TERMOUT_EN,
        USBMIDI_ep6_TD_TERMOUT_EN,
        USBMIDI_ep7_TD_TERMOUT_EN,
        USBMIDI_ep8_TD_TERMOUT_EN
    };
    volatile uint16 USBMIDI_inLength[USBMIDI_MAX_EP];
    const uint8 *USBMIDI_inDataPointer[USBMIDI_MAX_EP];
    volatile uint8 USBMIDI_inBufFull[USBMIDI_MAX_EP];
#endif /* ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u)) */


/*******************************************************************************
* Function Name: USBMIDI_Start
********************************************************************************
*
* Summary:
*  This function initialize the USB SIE, arbiter and the
*  endpoint APIs, including setting the D+ Pullup
*
* Parameters:
*  device: Contains the device number of the desired device descriptor.
*          The device number can be found in the Device Descriptor Tab of
*          "Configure" dialog, under the settings of desired Device Descriptor,
*          in the "Device Number" field.
*  mode: The operating voltage. This determines whether the voltage regulator
*        is enabled for 5V operation or if pass through mode is used for 3.3V
*        operation. Symbolic names and their associated values are given in the
*        following table.
*       USBMIDI_3V_OPERATION - Disable voltage regulator and pass-thru
*                                       Vcc for pull-up
*       USBMIDI_5V_OPERATION - Enable voltage regulator and use
*                                       regulator for pull-up
*       USBMIDI_DWR_VDDD_OPERATION - Enable or Disable voltage
*                         regulator depend on Vddd Voltage configuration in DWR.
*
* Return:
*   None.
*
* Global variables:
*  The USBMIDI_intiVar variable is used to indicate initial
*  configuration of this component. The variable is initialized to zero (0u)
*  and set to one (1u) the first time USBMIDI_Start() is called.
*  This allows for component Re-Start without unnecessary re-initialization
*  in all subsequent calls to the USBMIDI_Start() routine.
*  If re-initialization of the component is required the variable should be set
*  to zero before call of UART_Start() routine, or the user may call
*  USBMIDI_Init() and USBMIDI_InitComponent() as done
*  in the USBMIDI_Start() routine.
*
* Side Effects:
*   This function will reset all communication states to default.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_Start(uint8 device, uint8 mode) 
{
    /* If not Initialized then initialize all required hardware and software */
    if(USBMIDI_initVar == 0u)
    {
        USBMIDI_Init();
        USBMIDI_initVar = 1u;
    }
    USBMIDI_InitComponent(device, mode);
}


/*******************************************************************************
* Function Name: USBMIDI_Init
********************************************************************************
*
* Summary:
*  Initialize component's hardware. Usually called in USBMIDI_Start().
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_Init(void) 
{
    uint8 enableInterrupts;
    #if(USBMIDI_EP_MM != USBMIDI__EP_MANUAL)
        uint16 i;
    #endif   /*  USBMIDI_EP_MM != USBMIDI__EP_MANUAL */

    enableInterrupts = CyEnterCriticalSection();

    /* Enable USB block  */
    USBMIDI_PM_ACT_CFG_REG |= USBMIDI_PM_ACT_EN_FSUSB;
    /* Enable USB block for Standby Power Mode */
    USBMIDI_PM_STBY_CFG_REG |= USBMIDI_PM_STBY_EN_FSUSB;

    /* Enable core clock */
    USBMIDI_USB_CLK_EN_REG = USBMIDI_USB_CLK_ENABLE;

    USBMIDI_CR1_REG = USBMIDI_CR1_ENABLE_LOCK;

    /* ENABLING USBIO PADS IN USB MODE FROM I/O MODE */
    /* Ensure USB transmit enable is low (USB_USBIO_CR0.ten). - Manual Transmission - Disabled */
    USBMIDI_USBIO_CR0_REG &= ((uint8)(~USBMIDI_USBIO_CR0_TEN));
    CyDelayUs(0u);  /*~50ns delay */
    /* Disable the USBIO by asserting PM.USB_CR0.fsusbio_pd_n(Inverted)
    *  high. This will have been set low by the power manger out of reset.
    *  Also confirm USBIO pull-up disabled
    */
    USBMIDI_PM_USB_CR0_REG &= ((uint8)(~(USBMIDI_PM_USB_CR0_PD_N |
                                                  USBMIDI_PM_USB_CR0_PD_PULLUP_N)));

    /* Select iomode to USB mode*/
    USBMIDI_USBIO_CR1_REG &= ((uint8)(~USBMIDI_USBIO_CR1_IOMODE));

    /* Enable the USBIO reference by setting PM.USB_CR0.fsusbio_ref_en.*/
    USBMIDI_PM_USB_CR0_REG |= USBMIDI_PM_USB_CR0_REF_EN;
    /* The reference will be available 1 us after the regulator is enabled */
    CyDelayUs(1u);
    /* OR 40us after power restored */
    CyDelayUs(40u);
    /* Ensure the single ended disable bits are low (PRT15.INP_DIS[7:6])(input receiver enabled). */
    USBMIDI_DM_INP_DIS_REG &= ((uint8)(~USBMIDI_DM_MASK));
    USBMIDI_DP_INP_DIS_REG &= ((uint8)(~USBMIDI_DP_MASK));

    /* Enable USBIO */
    USBMIDI_PM_USB_CR0_REG |= USBMIDI_PM_USB_CR0_PD_N;
    CyDelayUs(2u);
    /* Set the USBIO pull-up enable */
    USBMIDI_PM_USB_CR0_REG |= USBMIDI_PM_USB_CR0_PD_PULLUP_N;

    /* Write WAx */
    CY_SET_REG8(USBMIDI_ARB_RW1_WA_PTR,     0u);
    CY_SET_REG8(USBMIDI_ARB_RW1_WA_MSB_PTR, 0u);

    #if(USBMIDI_EP_MM != USBMIDI__EP_MANUAL)
        /* Init transfer descriptor. This will be used to detect the DMA state - initialized or not. */
        for (i = 0u; i < USBMIDI_MAX_EP; i++)
        {
            USBMIDI_DmaTd[i] = DMA_INVALID_TD;
            #if ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u))
                USBMIDI_DmaNextTd[i] = DMA_INVALID_TD;
            #endif /* ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u)) */
        }
    #endif   /*  USBMIDI_EP_MM != USBMIDI__EP_MANUAL */

    CyExitCriticalSection(enableInterrupts);


    /* Set the bus reset Interrupt. */
    (void) CyIntSetVector(USBMIDI_BUS_RESET_VECT_NUM,   &USBMIDI_BUS_RESET_ISR);
    CyIntSetPriority(USBMIDI_BUS_RESET_VECT_NUM, USBMIDI_BUS_RESET_PRIOR);

    /* Set the SOF Interrupt. */
    #if(USBMIDI_SOF_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_SOF_VECT_NUM,   &USBMIDI_SOF_ISR);
        CyIntSetPriority(USBMIDI_SOF_VECT_NUM, USBMIDI_SOF_PRIOR);
    #endif   /*  USBMIDI_SOF_ISR_REMOVE */

    /* Set the Control Endpoint Interrupt. */
    (void) CyIntSetVector(USBMIDI_EP_0_VECT_NUM,   &USBMIDI_EP_0_ISR);
    CyIntSetPriority(USBMIDI_EP_0_VECT_NUM, USBMIDI_EP_0_PRIOR);

    /* Set the Data Endpoint 1 Interrupt. */
    #if(USBMIDI_EP1_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_1_VECT_NUM,   &USBMIDI_EP_1_ISR);
        CyIntSetPriority(USBMIDI_EP_1_VECT_NUM, USBMIDI_EP_1_PRIOR);
    #endif   /*  USBMIDI_EP1_ISR_REMOVE */

    /* Set the Data Endpoint 2 Interrupt. */
    #if(USBMIDI_EP2_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_2_VECT_NUM,   &USBMIDI_EP_2_ISR);
        CyIntSetPriority(USBMIDI_EP_2_VECT_NUM, USBMIDI_EP_2_PRIOR);
    #endif   /*  USBMIDI_EP2_ISR_REMOVE */

    /* Set the Data Endpoint 3 Interrupt. */
    #if(USBMIDI_EP3_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_3_VECT_NUM,   &USBMIDI_EP_3_ISR);
        CyIntSetPriority(USBMIDI_EP_3_VECT_NUM, USBMIDI_EP_3_PRIOR);
    #endif   /*  USBMIDI_EP3_ISR_REMOVE */

    /* Set the Data Endpoint 4 Interrupt. */
    #if(USBMIDI_EP4_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_4_VECT_NUM,   &USBMIDI_EP_4_ISR);
        CyIntSetPriority(USBMIDI_EP_4_VECT_NUM, USBMIDI_EP_4_PRIOR);
    #endif   /*  USBMIDI_EP4_ISR_REMOVE */

    /* Set the Data Endpoint 5 Interrupt. */
    #if(USBMIDI_EP5_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_5_VECT_NUM,   &USBMIDI_EP_5_ISR);
        CyIntSetPriority(USBMIDI_EP_5_VECT_NUM, USBMIDI_EP_5_PRIOR);
    #endif   /*  USBMIDI_EP5_ISR_REMOVE */

    /* Set the Data Endpoint 6 Interrupt. */
    #if(USBMIDI_EP6_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_6_VECT_NUM,   &USBMIDI_EP_6_ISR);
        CyIntSetPriority(USBMIDI_EP_6_VECT_NUM, USBMIDI_EP_6_PRIOR);
    #endif   /*  USBMIDI_EP6_ISR_REMOVE */

     /* Set the Data Endpoint 7 Interrupt. */
    #if(USBMIDI_EP7_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_7_VECT_NUM,   &USBMIDI_EP_7_ISR);
        CyIntSetPriority(USBMIDI_EP_7_VECT_NUM, USBMIDI_EP_7_PRIOR);
    #endif   /*  USBMIDI_EP7_ISR_REMOVE */

    /* Set the Data Endpoint 8 Interrupt. */
    #if(USBMIDI_EP8_ISR_REMOVE == 0u)
        (void) CyIntSetVector(USBMIDI_EP_8_VECT_NUM,   &USBMIDI_EP_8_ISR);
        CyIntSetPriority(USBMIDI_EP_8_VECT_NUM, USBMIDI_EP_8_PRIOR);
    #endif   /*  USBMIDI_EP8_ISR_REMOVE */

    #if((USBMIDI_EP_MM != USBMIDI__EP_MANUAL) && (USBMIDI_ARB_ISR_REMOVE == 0u))
        /* Set the ARB Interrupt. */
        (void) CyIntSetVector(USBMIDI_ARB_VECT_NUM,   &USBMIDI_ARB_ISR);
        CyIntSetPriority(USBMIDI_ARB_VECT_NUM, USBMIDI_ARB_PRIOR);
    #endif   /*  USBMIDI_EP_MM != USBMIDI__EP_MANUAL */

}


/*******************************************************************************
* Function Name: USBMIDI_InitComponent
********************************************************************************
*
* Summary:
*  Initialize the component, except for the HW which is done one time in
*  the Start function.  This function pulls up D+.
*
* Parameters:
*  device: Contains the device number of the desired device descriptor.
*          The device number can be found in the Device Descriptor Tab of
*          "Configure" dialog, under the settings of desired Device Descriptor,
*          in the "Device Number" field.
*  mode: The operating voltage. This determines whether the voltage regulator
*        is enabled for 5V operation or if pass through mode is used for 3.3V
*        operation. Symbolic names and their associated values are given in the
*        following table.
*       USBMIDI_3V_OPERATION - Disable voltage regulator and pass-thru
*                                       Vcc for pull-up
*       USBMIDI_5V_OPERATION - Enable voltage regulator and use
*                                       regulator for pull-up
*       USBMIDI_DWR_VDDD_OPERATION - Enable or Disable voltage
*                         regulator depend on Vddd Voltage configuration in DWR.
*
* Return:
*   None.
*
* Global variables:
*   USBMIDI_device: Contains the device number of the desired device
*       descriptor. The device number can be found in the Device Descriptor Tab
*       of "Configure" dialog, under the settings of desired Device Descriptor,
*       in the "Device Number" field.
*   USBMIDI_transferState: This variable used by the communication
*       functions to handle current transfer state. Initialized to
*       TRANS_STATE_IDLE in this API.
*   USBMIDI_configuration: Contains current configuration number
*       which is set by the Host using SET_CONFIGURATION request.
*       Initialized to zero in this API.
*   USBMIDI_deviceAddress: Contains current device address. This
*       variable is initialized to zero in this API. Host starts to communicate
*      to device with address 0 and then set it to whatever value using
*      SET_ADDRESS request.
*   USBMIDI_deviceStatus: initialized to 0.
*       This is two bit variable which contain power status in first bit
*       (DEVICE_STATUS_BUS_POWERED or DEVICE_STATUS_SELF_POWERED) and remote
*       wakeup status (DEVICE_STATUS_REMOTE_WAKEUP) in second bit.
*   USBMIDI_lastPacketSize initialized to 0;
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_InitComponent(uint8 device, uint8 mode) 
{
    /* Initialize _hidProtocol variable to comply with
    *  HID 7.2.6 Set_Protocol Request:
    *  "When initialized, all devices default to report protocol."
    */
    #if defined(USBMIDI_ENABLE_HID_CLASS)
        uint8 i;

        for (i = 0u; i < USBMIDI_MAX_INTERFACES_NUMBER; i++)
        {
            USBMIDI_hidProtocol[i] = USBMIDI_PROTOCOL_REPORT;
        }
    #endif /* USBMIDI_ENABLE_HID_CLASS */

    /* Enable Interrupts. */
    CyIntEnable(USBMIDI_BUS_RESET_VECT_NUM);
    CyIntEnable(USBMIDI_EP_0_VECT_NUM);
    #if(USBMIDI_EP1_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_1_VECT_NUM);
    #endif   /*  USBMIDI_EP1_ISR_REMOVE */
    #if(USBMIDI_EP2_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_2_VECT_NUM);
    #endif   /*  USBMIDI_EP2_ISR_REMOVE */
    #if(USBMIDI_EP3_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_3_VECT_NUM);
    #endif   /*  USBMIDI_EP3_ISR_REMOVE */
    #if(USBMIDI_EP4_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_4_VECT_NUM);
    #endif   /*  USBMIDI_EP4_ISR_REMOVE */
    #if(USBMIDI_EP5_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_5_VECT_NUM);
    #endif   /*  USBMIDI_EP5_ISR_REMOVE */
    #if(USBMIDI_EP6_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_6_VECT_NUM);
    #endif   /*  USBMIDI_EP6_ISR_REMOVE */
    #if(USBMIDI_EP7_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_7_VECT_NUM);
    #endif   /*  USBMIDI_EP7_ISR_REMOVE */
    #if(USBMIDI_EP8_ISR_REMOVE == 0u)
        CyIntEnable(USBMIDI_EP_8_VECT_NUM);
    #endif   /*  USBMIDI_EP8_ISR_REMOVE */
    #if((USBMIDI_EP_MM != USBMIDI__EP_MANUAL) && (USBMIDI_ARB_ISR_REMOVE == 0u))
        /* usb arb interrupt enable */
        USBMIDI_ARB_INT_EN_REG = USBMIDI_ARB_INT_MASK;
        CyIntEnable(USBMIDI_ARB_VECT_NUM);
    #endif   /*  USBMIDI_EP_MM != USBMIDI__EP_MANUAL */

    /* Arbiter configuration for DMA transfers */
    #if(USBMIDI_EP_MM != USBMIDI__EP_MANUAL)
        #if(USBMIDI_EP_MM == USBMIDI__EP_DMAMANUAL)
            USBMIDI_ARB_CFG_REG = USBMIDI_ARB_CFG_MANUAL_DMA;
        #endif   /*  USBMIDI_EP_MM == USBMIDI__EP_DMAMANUAL */
        #if(USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO)
            /*Set cfg cmplt this rises DMA request when the full configuration is done */
            USBMIDI_ARB_CFG_REG = USBMIDI_ARB_CFG_AUTO_DMA | USBMIDI_ARB_CFG_AUTO_MEM;
            #if(USBMIDI_EP_DMA_AUTO_OPT == 0u)
                /* Init interrupt which handles verification of the successful DMA transaction */
                USBMIDI_EP_DMA_Done_isr_StartEx(USBMIDI_EP_DMA_DONE_ISR);
                USBMIDI_EP17_DMA_Done_SR_InterruptEnable();
                USBMIDI_EP8_DMA_Done_SR_InterruptEnable();
            #endif /* USBMIDI_EP_DMA_AUTO_OPT == 0u */
        #endif   /*  USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO */
    #endif   /*  USBMIDI_EP_MM != USBMIDI__EP_MANUAL */

    USBMIDI_transferState = USBMIDI_TRANS_STATE_IDLE;

    /* USB Locking: Enabled, VRegulator: depend on mode or DWR Voltage configuration*/
    switch(mode)
    {
        case USBMIDI_3V_OPERATION:
            USBMIDI_CR1_REG = USBMIDI_CR1_ENABLE_LOCK;
            break;
        case USBMIDI_5V_OPERATION:
            USBMIDI_CR1_REG = USBMIDI_CR1_ENABLE_LOCK | USBMIDI_CR1_REG_ENABLE;
            break;
        default:   /*USBMIDI_DWR_VDDD_OPERATION */
            #if(USBMIDI_VDDD_MV < USBMIDI_3500MV)
                USBMIDI_CR1_REG = USBMIDI_CR1_ENABLE_LOCK;
            #else
                USBMIDI_CR1_REG = USBMIDI_CR1_ENABLE_LOCK | USBMIDI_CR1_REG_ENABLE;
            #endif /*  USBMIDI_VDDD_MV < USBMIDI_3500MV */
            break;
    }

    /* Record the descriptor selection */
    USBMIDI_device = device;

    /* Clear all of the component data */
    USBMIDI_configuration = 0u;
    USBMIDI_interfaceNumber = 0u;
    USBMIDI_configurationChanged = 0u;
    USBMIDI_deviceAddress  = 0u;
    USBMIDI_deviceStatus = 0u;

    USBMIDI_lastPacketSize = 0u;

    /*  ACK Setup, Stall IN/OUT */
    CY_SET_REG8(USBMIDI_EP0_CR_PTR, USBMIDI_MODE_STALL_IN_OUT);

    /* Enable the SIE with an address 0 */
    CY_SET_REG8(USBMIDI_CR0_PTR, USBMIDI_CR0_ENABLE);

    /* Workaround for PSOC5LP */
    CyDelayCycles(1u);

    /* Finally, Enable d+ pullup and select iomode to USB mode*/
    CY_SET_REG8(USBMIDI_USBIO_CR1_PTR, USBMIDI_USBIO_CR1_USBPUEN);
}


/*******************************************************************************
* Function Name: USBMIDI_ReInitComponent
********************************************************************************
*
* Summary:
*  This function reinitialize the component configuration and is
*  intend to be called from the Reset interrupt.
*
* Parameters:
*  None.
*
* Return:
*   None.
*
* Global variables:
*   USBMIDI_device: Contains the device number of the desired device
*        descriptor. The device number can be found in the Device Descriptor Tab
*       of "Configure" dialog, under the settings of desired Device Descriptor,
*       in the "Device Number" field.
*   USBMIDI_transferState: This variable used by the communication
*       functions to handle current transfer state. Initialized to
*       TRANS_STATE_IDLE in this API.
*   USBMIDI_configuration: Contains current configuration number
*       which is set by the Host using SET_CONFIGURATION request.
*       Initialized to zero in this API.
*   USBMIDI_deviceAddress: Contains current device address. This
*       variable is initialized to zero in this API. Host starts to communicate
*      to device with address 0 and then set it to whatever value using
*      SET_ADDRESS request.
*   USBMIDI_deviceStatus: initialized to 0.
*       This is two bit variable which contain power status in first bit
*       (DEVICE_STATUS_BUS_POWERED or DEVICE_STATUS_SELF_POWERED) and remote
*       wakeup status (DEVICE_STATUS_REMOTE_WAKEUP) in second bit.
*   USBMIDI_lastPacketSize initialized to 0;
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_ReInitComponent(void) 
{
    /* Initialize _hidProtocol variable to comply with HID 7.2.6 Set_Protocol
    *  Request: "When initialized, all devices default to report protocol."
    */
    #if defined(USBMIDI_ENABLE_HID_CLASS)
        uint8 i;

        for (i = 0u; i < USBMIDI_MAX_INTERFACES_NUMBER; i++)
        {
            USBMIDI_hidProtocol[i] = USBMIDI_PROTOCOL_REPORT;
        }
    #endif /* USBMIDI_ENABLE_HID_CLASS */

    USBMIDI_transferState = USBMIDI_TRANS_STATE_IDLE;

    /* Clear all of the component data */
    USBMIDI_configuration = 0u;
    USBMIDI_interfaceNumber = 0u;
    USBMIDI_configurationChanged = 0u;
    USBMIDI_deviceAddress  = 0u;
    USBMIDI_deviceStatus = 0u;

    USBMIDI_lastPacketSize = 0u;


    /*  ACK Setup, Stall IN/OUT */
    CY_SET_REG8(USBMIDI_EP0_CR_PTR, USBMIDI_MODE_STALL_IN_OUT);

    /* Enable the SIE with an address 0 */
    CY_SET_REG8(USBMIDI_CR0_PTR, USBMIDI_CR0_ENABLE);

}


/*******************************************************************************
* Function Name: USBMIDI_Stop
********************************************************************************
*
* Summary:
*  This function shuts down the USB function including to release
*  the D+ Pullup and disabling the SIE.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*   USBMIDI_configuration: Contains current configuration number
*       which is set by the Host using SET_CONFIGURATION request.
*       Initialized to zero in this API.
*   USBMIDI_deviceAddress: Contains current device address. This
*       variable is initialized to zero in this API. Host starts to communicate
*      to device with address 0 and then set it to whatever value using
*      SET_ADDRESS request.
*   USBMIDI_deviceStatus: initialized to 0.
*       This is two bit variable which contain power status in first bit
*       (DEVICE_STATUS_BUS_POWERED or DEVICE_STATUS_SELF_POWERED) and remote
*       wakeup status (DEVICE_STATUS_REMOTE_WAKEUP) in second bit.
*   USBMIDI_configurationChanged: This variable is set to one after
*       SET_CONFIGURATION request and cleared in this function.
*   USBMIDI_intiVar variable is set to zero
*
*******************************************************************************/
void USBMIDI_Stop(void) 
{

    #if(USBMIDI_EP_MM != USBMIDI__EP_MANUAL)
        USBMIDI_Stop_DMA(USBMIDI_MAX_EP);     /* Stop all DMAs */
    #endif   /*  USBMIDI_EP_MM != USBMIDI__EP_MANUAL */

    /* Disable the SIE */
    USBMIDI_CR0_REG &= (uint8)(~USBMIDI_CR0_ENABLE);
    /* Disable the d+ pullup */
    USBMIDI_USBIO_CR1_REG &= (uint8)(~USBMIDI_USBIO_CR1_USBPUEN);
    /* Disable USB in ACT PM */
    USBMIDI_PM_ACT_CFG_REG &= (uint8)(~USBMIDI_PM_ACT_EN_FSUSB);
    /* Disable USB block for Standby Power Mode */
    USBMIDI_PM_STBY_CFG_REG &= (uint8)(~USBMIDI_PM_STBY_EN_FSUSB);

    /* Disable the reset and EP interrupts */
    CyIntDisable(USBMIDI_BUS_RESET_VECT_NUM);
    CyIntDisable(USBMIDI_EP_0_VECT_NUM);
    #if(USBMIDI_EP1_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_1_VECT_NUM);
    #endif   /*  USBMIDI_EP1_ISR_REMOVE */
    #if(USBMIDI_EP2_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_2_VECT_NUM);
    #endif   /*  USBMIDI_EP2_ISR_REMOVE */
    #if(USBMIDI_EP3_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_3_VECT_NUM);
    #endif   /*  USBMIDI_EP3_ISR_REMOVE */
    #if(USBMIDI_EP4_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_4_VECT_NUM);
    #endif   /*  USBMIDI_EP4_ISR_REMOVE */
    #if(USBMIDI_EP5_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_5_VECT_NUM);
    #endif   /*  USBMIDI_EP5_ISR_REMOVE */
    #if(USBMIDI_EP6_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_6_VECT_NUM);
    #endif   /*  USBMIDI_EP6_ISR_REMOVE */
    #if(USBMIDI_EP7_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_7_VECT_NUM);
    #endif   /*  USBMIDI_EP7_ISR_REMOVE */
    #if(USBMIDI_EP8_ISR_REMOVE == 0u)
        CyIntDisable(USBMIDI_EP_8_VECT_NUM);
    #endif   /*  USBMIDI_EP8_ISR_REMOVE */

    /* Clear all of the component data */
    USBMIDI_configuration = 0u;
    USBMIDI_interfaceNumber = 0u;
    USBMIDI_configurationChanged = 0u;
    USBMIDI_deviceAddress  = 0u;
    USBMIDI_deviceStatus = 0u;
    USBMIDI_initVar = 0u;

}


/*******************************************************************************
* Function Name: USBMIDI_CheckActivity
********************************************************************************
*
* Summary:
*  Returns the activity status of the bus.  Clears the status hardware to
*  provide fresh activity status on the next call of this routine.
*
* Parameters:
*  None.
*
* Return:
*  1 - If bus activity was detected since the last call to this function
*  0 - If bus activity not was detected since the last call to this function
*
*******************************************************************************/
uint8 USBMIDI_CheckActivity(void) 
{
    uint8 r;

    r = CY_GET_REG8(USBMIDI_CR1_PTR);
    CY_SET_REG8(USBMIDI_CR1_PTR, (r & ((uint8)(~USBMIDI_CR1_BUS_ACTIVITY))));

    return((r & USBMIDI_CR1_BUS_ACTIVITY) >> USBMIDI_CR1_BUS_ACTIVITY_SHIFT);
}


/*******************************************************************************
* Function Name: USBMIDI_GetConfiguration
********************************************************************************
*
* Summary:
*  Returns the current configuration setting
*
* Parameters:
*  None.
*
* Return:
*  configuration.
*
*******************************************************************************/
uint8 USBMIDI_GetConfiguration(void) 
{
    return(USBMIDI_configuration);
}


/*******************************************************************************
* Function Name: USBMIDI_IsConfigurationChanged
********************************************************************************
*
* Summary:
*  Returns the clear on read configuration state. It is usefull when PC send
*  double SET_CONFIGURATION request with same configuration number.
*
* Parameters:
*  None.
*
* Return:
*  Not zero value when new configuration has been changed, otherwise zero is
*  returned.
*
* Global variables:
*   USBMIDI_configurationChanged: This variable is set to one after
*       SET_CONFIGURATION request and cleared in this function.
*
*******************************************************************************/
uint8 USBMIDI_IsConfigurationChanged(void) 
{
    uint8 res = 0u;

    if(USBMIDI_configurationChanged != 0u)
    {
        res = USBMIDI_configurationChanged;
        USBMIDI_configurationChanged = 0u;
    }

    return(res);
}


/*******************************************************************************
* Function Name: USBMIDI_GetInterfaceSetting
********************************************************************************
*
* Summary:
*  Returns the alternate setting from current interface
*
* Parameters:
*  uint8 interfaceNumber, interface number
*
* Return:
*  Alternate setting.
*
*******************************************************************************/
uint8  USBMIDI_GetInterfaceSetting(uint8 interfaceNumber)
                                                    
{
    return(USBMIDI_interfaceSetting[interfaceNumber]);
}


/*******************************************************************************
* Function Name: USBMIDI_GetEPState
********************************************************************************
*
* Summary:
*  Returned the state of the requested endpoint.
*
* Parameters:
*  epNumber: Endpoint Number
*
* Return:
*  State of the requested endpoint.
*
*******************************************************************************/
uint8 USBMIDI_GetEPState(uint8 epNumber) 
{
    return(USBMIDI_EP[epNumber].apiEpState);
}


/*******************************************************************************
* Function Name: USBMIDI_GetEPCount
********************************************************************************
*
* Summary:
*  This function supports Data Endpoints only(EP1-EP8).
*  Returns the transfer count for the requested endpoint.  The value from
*  the count registers includes 2 counts for the two byte checksum of the
*  packet.  This function subtracts the two counts.
*
* Parameters:
*  epNumber: Data Endpoint Number.
*            Valid values are between 1 and 8.
*
* Return:
*  Returns the current byte count from the specified endpoint or 0 for an
*  invalid endpoint.
*
*******************************************************************************/
uint16 USBMIDI_GetEPCount(uint8 epNumber) 
{
    uint8 ri;
    uint16 result = 0u;

    if((epNumber > USBMIDI_EP0) && (epNumber < USBMIDI_MAX_EP))
    {
        ri = ((epNumber - USBMIDI_EP1) << USBMIDI_EPX_CNTX_ADDR_SHIFT);

        result = (uint8)(CY_GET_REG8((reg8 *)(USBMIDI_SIE_EP1_CNT0_IND + ri)) &
                          USBMIDI_EPX_CNT0_MASK);
        result = (result << 8u) | CY_GET_REG8((reg8 *)(USBMIDI_SIE_EP1_CNT1_IND + ri));
        result -= USBMIDI_EPX_CNTX_CRC_COUNT;
    }
    return(result);
}


#if(USBMIDI_EP_MM != USBMIDI__EP_MANUAL)


    /*******************************************************************************
    * Function Name: USBMIDI_InitEP_DMA
    ********************************************************************************
    *
    * Summary:
    *  This function allocates and initializes a DMA channel to be used by the
    *  USBMIDI_LoadInEP() or USBMIDI_ReadOutEP() APIs for data
    *  transfer.
    *
    * Parameters:
    *  epNumber: Contains the data endpoint number.
    *            Valid values are between 1 and 8.
    *  *pData: Pointer to a data array that is related to the EP transfers.
    *
    * Return:
    *  None.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void USBMIDI_InitEP_DMA(uint8 epNumber, const uint8* pData)
                                                                    
    {
        uint16 src;
        uint16 dst;
        #if (CY_PSOC3)                  /* PSoC 3 */
            src = HI16(CYDEV_SRAM_BASE);
            dst = HI16(CYDEV_PERIPH_BASE);
            pData = pData;
        #else                           /* PSoC 5 */
            if((USBMIDI_EP[epNumber].addr & USBMIDI_DIR_IN) != 0u )
            {   /* for the IN EP source is the SRAM memory buffer */
                src = HI16(pData);
                dst = HI16(CYDEV_PERIPH_BASE);
            }
            else
            {   /* for the OUT EP source is the SIE register */
                src = HI16(CYDEV_PERIPH_BASE);
                dst = HI16(pData);
            }
        #endif  /*  C51 */
        switch(epNumber)
        {
            case USBMIDI_EP1:
                #if(USBMIDI_DMA1_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep1_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA1_REMOVE */
                break;
            case USBMIDI_EP2:
                #if(USBMIDI_DMA2_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep2_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA2_REMOVE */
                break;
            case USBMIDI_EP3:
                #if(USBMIDI_DMA3_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep3_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA3_REMOVE */
                break;
            case USBMIDI_EP4:
                #if(USBMIDI_DMA4_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep4_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA4_REMOVE */
                break;
            case USBMIDI_EP5:
                #if(USBMIDI_DMA5_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep5_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA5_REMOVE */
                break;
            case USBMIDI_EP6:
                #if(USBMIDI_DMA6_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep6_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA6_REMOVE */
                break;
            case USBMIDI_EP7:
                #if(USBMIDI_DMA7_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep7_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA7_REMOVE */
                break;
            case USBMIDI_EP8:
                #if(USBMIDI_DMA8_REMOVE == 0u)
                    USBMIDI_DmaChan[epNumber] = USBMIDI_ep8_DmaInitialize(
                        USBMIDI_DMA_BYTES_PER_BURST, USBMIDI_DMA_REQUEST_PER_BURST, src, dst);
                #endif   /*  USBMIDI_DMA8_REMOVE */
                break;
            default:
                /* Do not support EP0 DMA transfers */
                break;
        }
        if((epNumber > USBMIDI_EP0) && (epNumber < USBMIDI_MAX_EP))
        {
            USBMIDI_DmaTd[epNumber] = CyDmaTdAllocate();
            #if ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u))
                USBMIDI_DmaNextTd[epNumber] = CyDmaTdAllocate();
            #endif /*  ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u)) */

        }
    }


    /*******************************************************************************
    * Function Name: USBMIDI_Stop_DMA
    ********************************************************************************
    *
    * Summary: Stops and free DMA
    *
    * Parameters:
    *  epNumber: Contains the data endpoint number or
    *           USBMIDI_MAX_EP to stop all DMAs
    *
    * Return:
    *  None.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void USBMIDI_Stop_DMA(uint8 epNumber) 
    {
        uint8 i;
        i = (epNumber < USBMIDI_MAX_EP) ? epNumber : USBMIDI_EP1;
        do
        {
            if(USBMIDI_DmaTd[i] != DMA_INVALID_TD)
            {
                (void) CyDmaChDisable(USBMIDI_DmaChan[i]);
                CyDmaTdFree(USBMIDI_DmaTd[i]);
                USBMIDI_DmaTd[i] = DMA_INVALID_TD;
            }
            #if ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u))
                if(USBMIDI_DmaNextTd[i] != DMA_INVALID_TD)
                {
                    CyDmaTdFree(USBMIDI_DmaNextTd[i]);
                    USBMIDI_DmaNextTd[i] = DMA_INVALID_TD;
                }
            #endif /* ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u)) */
            i++;
        }while((i < USBMIDI_MAX_EP) && (epNumber == USBMIDI_MAX_EP));
    }

#endif /*  USBMIDI_EP_MM != USBMIDI__EP_MANUAL */


#if ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u))


    /*******************************************************************************
    * Function Name: USBMIDI_LoadNextInEP
    ********************************************************************************
    *
    * Summary:
    *  This internal function is used for IN endpoint DMA reconfiguration in
    *  Auto DMA mode.
    *
    * Parameters:
    *  epNumber: Contains the data endpoint number.
    *  mode:   0 - Configure DMA to send the the rest of data.
    *          1 - Configure DMA to repeat 2 last bytes of the first burst.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void USBMIDI_LoadNextInEP(uint8 epNumber, uint8 mode) 
    {
        reg16 *convert;

        if(mode == 0u)
        {
            /* Configure DMA to send the the rest of data */
            /* CyDmaTdSetConfiguration API is optimised to change only transfer length and configure TD */
            convert = (reg16 *) &CY_DMA_TDMEM_STRUCT_PTR[USBMIDI_DmaTd[epNumber]].TD0[0u];
            /* Set transfer length */
            CY_SET_REG16(convert, USBMIDI_inLength[epNumber] - USBMIDI_DMA_BYTES_PER_BURST);
            /* CyDmaTdSetAddress API is optimized to change only source address */
            convert = (reg16 *) &CY_DMA_TDMEM_STRUCT_PTR[USBMIDI_DmaTd[epNumber]].TD1[0u];
            CY_SET_REG16(convert, LO16((uint32)USBMIDI_inDataPointer[epNumber] +
                                            USBMIDI_DMA_BYTES_PER_BURST));
            USBMIDI_inBufFull[epNumber] = 1u;
        }
        else
        {
            /* Configure DMA to repeat 2 last bytes of the first burst. */
            /* CyDmaTdSetConfiguration API is optimised to change only transfer length and configure TD */
            convert = (reg16 *) &CY_DMA_TDMEM_STRUCT_PTR[USBMIDI_DmaTd[epNumber]].TD0[0u];
            /* Set transfer length */
            CY_SET_REG16(convert, USBMIDI_DMA_BYTES_REPEAT);
            /* CyDmaTdSetAddress API is optimized to change only source address */
            convert = (reg16 *) &CY_DMA_TDMEM_STRUCT_PTR[USBMIDI_DmaTd[epNumber]].TD1[0u];
            CY_SET_REG16(convert,  LO16((uint32)USBMIDI_inDataPointer[epNumber] +
                                   USBMIDI_DMA_BYTES_PER_BURST - USBMIDI_DMA_BYTES_REPEAT));
        }

        /* CyDmaChSetInitialTd API is optimised to init TD */
        CY_DMA_CH_STRUCT_PTR[USBMIDI_DmaChan[epNumber]].basic_status[1u] = USBMIDI_DmaTd[epNumber];
    }
#endif /* ((USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO) && (USBMIDI_EP_DMA_AUTO_OPT == 0u)) */


/*******************************************************************************
* Function Name: USBMIDI_LoadInEP
********************************************************************************
*
* Summary:
*  Loads and enables the specified USB data endpoint for an IN transfer.
*
* Parameters:
*  epNumber: Contains the data endpoint number.
*            Valid values are between 1 and 8.
*  *pData: A pointer to a data array from which the data for the endpoint space
*          is loaded.
*  length: The number of bytes to transfer from the array and then send as a
*          result of an IN request. Valid values are between 0 and 512.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_LoadInEP(uint8 epNumber, const uint8 pData[], uint16 length)
                                                                        
{
    uint8 ri;
    reg8 *p;
    #if(USBMIDI_EP_MM == USBMIDI__EP_MANUAL)
        uint16 i;
    #endif /*  USBMIDI_EP_MM == USBMIDI__EP_MANUAL */

    if((epNumber > USBMIDI_EP0) && (epNumber < USBMIDI_MAX_EP))
    {
        ri = ((epNumber - USBMIDI_EP1) << USBMIDI_EPX_CNTX_ADDR_SHIFT);
        p = (reg8 *)(USBMIDI_ARB_RW1_DR_IND + ri);

        #if(USBMIDI_EP_MM != USBMIDI__EP_DMAAUTO)
            /* Limits length to available buffer space, auto MM could send packets up to 1024 bytes */
            if(length > (USBMIDI_EPX_DATA_BUF_MAX - USBMIDI_EP[epNumber].buffOffset))
            {
                length = USBMIDI_EPX_DATA_BUF_MAX - USBMIDI_EP[epNumber].buffOffset;
            }
        #endif /*  USBMIDI_EP_MM != USBMIDI__EP_DMAAUTO */

        /* Set the count and data toggle */
        CY_SET_REG8((reg8 *)(USBMIDI_SIE_EP1_CNT0_IND + ri),
                            (length >> 8u) | (USBMIDI_EP[epNumber].epToggle));
        CY_SET_REG8((reg8 *)(USBMIDI_SIE_EP1_CNT1_IND + ri),  length & 0xFFu);

        #if(USBMIDI_EP_MM == USBMIDI__EP_MANUAL)
            if(pData != NULL)
            {
                /* Copy the data using the arbiter data register */
                for (i = 0u; i < length; i++)
                {
                    CY_SET_REG8(p, pData[i]);
                }
            }
            USBMIDI_EP[epNumber].apiEpState = USBMIDI_NO_EVENT_PENDING;
            /* Write the Mode register */
            CY_SET_REG8((reg8 *)(USBMIDI_SIE_EP1_CR0_IND + ri), USBMIDI_EP[epNumber].epMode);
        #else
            /* Init DMA if it was not initialized */
            if (USBMIDI_DmaTd[epNumber] == DMA_INVALID_TD)
            {
                USBMIDI_InitEP_DMA(epNumber, pData);
            }
        #endif /*  USBMIDI_EP_MM == USBMIDI__EP_MANUAL */

        #if(USBMIDI_EP_MM == USBMIDI__EP_DMAMANUAL)
            USBMIDI_EP[epNumber].apiEpState = USBMIDI_NO_EVENT_PENDING;
            if ((pData != NULL) && (length > 0u))
            {
                /* Enable DMA in mode2 for transferring data */
                (void) CyDmaChDisable(USBMIDI_DmaChan[epNumber]);
                (void) CyDmaTdSetConfiguration(USBMIDI_DmaTd[epNumber], length, CY_DMA_DISABLE_TD,
                                                                                 TD_TERMIN_EN | TD_INC_SRC_ADR);
                (void) CyDmaTdSetAddress(USBMIDI_DmaTd[epNumber],  LO16((uint32)pData), LO16((uint32)p));
                /* Enable the DMA */
                (void) CyDmaChSetInitialTd(USBMIDI_DmaChan[epNumber], USBMIDI_DmaTd[epNumber]);
                (void) CyDmaChEnable(USBMIDI_DmaChan[epNumber], 1u);
                /* Generate DMA request */
                * (reg8 *)(USBMIDI_ARB_EP1_CFG_IND + ri) |= USBMIDI_ARB_EPX_CFG_DMA_REQ;
                * (reg8 *)(USBMIDI_ARB_EP1_CFG_IND + ri) &= ((uint8)(~USBMIDI_ARB_EPX_CFG_DMA_REQ));
                /* Mode register will be written in arb ISR after DMA transfer complete */
            }
            else
            {
                /* When zero-length packet - write the Mode register directly */
                CY_SET_REG8((reg8 *)(USBMIDI_SIE_EP1_CR0_IND + ri), USBMIDI_EP[epNumber].epMode);
            }
        #endif /*  USBMIDI_EP_MM == USBMIDI__EP_DMAMANUAL */

        #if(USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO)
            if (pData != NULL)
            {
                /* Enable DMA in mode3 for transferring data */
                (void) CyDmaChDisable(USBMIDI_DmaChan[epNumber]);
            #if (USBMIDI_EP_DMA_AUTO_OPT == 0u)
                USBMIDI_inLength[epNumber] = length;
                USBMIDI_inDataPointer[epNumber] = pData;
                /* Configure DMA to send the data only for the first burst */
                (void) CyDmaTdSetConfiguration(USBMIDI_DmaTd[epNumber],
                    (length > USBMIDI_DMA_BYTES_PER_BURST) ? USBMIDI_DMA_BYTES_PER_BURST : length,
                    USBMIDI_DmaNextTd[epNumber], TD_TERMIN_EN | TD_INC_SRC_ADR);
                (void) CyDmaTdSetAddress(USBMIDI_DmaTd[epNumber],  LO16((uint32)pData), LO16((uint32)p));
                /* The second TD will be executed only when the first one fails.
                *  The intention of this TD is to generate NRQ interrupt
                *  and repeat 2 last bytes of the first burst.
                */
                (void) CyDmaTdSetConfiguration(USBMIDI_DmaNextTd[epNumber], 1u,
                                               USBMIDI_DmaNextTd[epNumber],
                                               USBMIDI_epX_TD_TERMOUT_EN[epNumber]);
                /* Configure DmaNextTd to clear Data ready status */
                (void) CyDmaTdSetAddress(USBMIDI_DmaNextTd[epNumber],  LO16((uint32)&clearInDataRdyStatus),
                                                                LO16((uint32)(USBMIDI_ARB_EP1_CFG_IND + ri)));
            #else /* Configure DMA to send all data*/
                (void) CyDmaTdSetConfiguration(USBMIDI_DmaTd[epNumber], length,
                                               USBMIDI_DmaTd[epNumber], TD_TERMIN_EN | TD_INC_SRC_ADR);
                (void) CyDmaTdSetAddress(USBMIDI_DmaTd[epNumber],  LO16((uint32)pData), LO16((uint32)p));
            #endif /* USBMIDI_EP_DMA_AUTO_OPT == 0u */    

                /* Clear Any potential pending DMA requests before starting the DMA channel to transfer data */
                (void) CyDmaClearPendingDrq(USBMIDI_DmaChan[epNumber]);
                /* Enable the DMA */
                (void) CyDmaChSetInitialTd(USBMIDI_DmaChan[epNumber], USBMIDI_DmaTd[epNumber]);
                (void) CyDmaChEnable(USBMIDI_DmaChan[epNumber], 1u);
            }
            else
            {
                USBMIDI_EP[epNumber].apiEpState = USBMIDI_NO_EVENT_PENDING;
                if(length > 0u)
                {
                #if (USBMIDI_EP_DMA_AUTO_OPT == 0u)
                    USBMIDI_inLength[epNumber] = length;
                    USBMIDI_inBufFull[epNumber] = 0u;
                    (void) CyDmaChDisable(USBMIDI_DmaChan[epNumber]);
                    /* Configure DMA to send the data only for the first burst */
                    (void) CyDmaTdSetConfiguration(
                        USBMIDI_DmaTd[epNumber], (length > USBMIDI_DMA_BYTES_PER_BURST) ?
                        USBMIDI_DMA_BYTES_PER_BURST : length,
                        USBMIDI_DmaNextTd[epNumber], TD_TERMIN_EN | TD_INC_SRC_ADR );
                    (void) CyDmaTdSetAddress(USBMIDI_DmaTd[epNumber],
                                             LO16((uint32)USBMIDI_inDataPointer[epNumber]), LO16((uint32)p));
                    /* Clear Any potential pending DMA requests before starting the DMA channel to transfer data */
                    (void) CyDmaClearPendingDrq(USBMIDI_DmaChan[epNumber]);
                    /* Enable the DMA */
                    (void) CyDmaChSetInitialTd(USBMIDI_DmaChan[epNumber], USBMIDI_DmaTd[epNumber]);
                    (void) CyDmaChEnable(USBMIDI_DmaChan[epNumber], 1u);
                #endif /* (USBMIDI_EP_DMA_AUTO_OPT == 0u) */

                    /* Set Data ready status, This will generate DMA request */
                    #ifndef USBMIDI_MANUAL_IN_EP_ARM
                        * (reg8 *)(USBMIDI_ARB_EP1_CFG_IND + ri) |= USBMIDI_ARB_EPX_CFG_IN_DATA_RDY;
                    #endif  /* USBMIDI_MANUAL_IN_EP_ARM */
                    /* Mode register will be written in arb ISR(In Buffer Full) after first DMA transfer complete */
                }
                else
                {
                    /* When zero-length packet - write the Mode register directly */
                    CY_SET_REG8((reg8 *)(USBMIDI_SIE_EP1_CR0_IND + ri), USBMIDI_EP[epNumber].epMode);
                }
            }
        #endif /*  USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO */
    }
}


/*******************************************************************************
* Function Name: USBMIDI_ReadOutEP
********************************************************************************
*
* Summary:
*  Read data from an endpoint.  The application must call
*  USBMIDI_GetEPState to see if an event is pending.
*
* Parameters:
*  epNumber: Contains the data endpoint number.
*            Valid values are between 1 and 8.
*  pData: A pointer to a data array from which the data for the endpoint space
*         is loaded.
*  length: The number of bytes to transfer from the USB Out endpoint and loads
*          it into data array. Valid values are between 0 and 1023. The function
*          moves fewer than the requested number of bytes if the host sends
*          fewer bytes than requested.
*
* Returns:
*  Number of bytes received, 0 for an invalid endpoint.
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint16 USBMIDI_ReadOutEP(uint8 epNumber, uint8 pData[], uint16 length)
                                                                        
{
    uint8 ri;
    reg8 *p;
    #if(USBMIDI_EP_MM == USBMIDI__EP_MANUAL)
        uint16 i;
    #endif /*  USBMIDI_EP_MM == USBMIDI__EP_MANUAL */
    #if(USBMIDI_EP_MM != USBMIDI__EP_DMAAUTO)
        uint16 xferCount;
    #endif /*  USBMIDI_EP_MM != USBMIDI__EP_DMAAUTO */

    if((epNumber > USBMIDI_EP0) && (epNumber < USBMIDI_MAX_EP) && (pData != NULL))
    {
        ri = ((epNumber - USBMIDI_EP1) << USBMIDI_EPX_CNTX_ADDR_SHIFT);
        p = (reg8 *)(USBMIDI_ARB_RW1_DR_IND + ri);

        #if(USBMIDI_EP_MM != USBMIDI__EP_DMAAUTO)
            /* Determine which is smaller the requested data or the available data */
            xferCount = USBMIDI_GetEPCount(epNumber);
            if (length > xferCount)
            {
                length = xferCount;
            }
        #endif /*  USBMIDI_EP_MM != USBMIDI__EP_DMAAUTO */

        #if(USBMIDI_EP_MM == USBMIDI__EP_MANUAL)
            /* Copy the data using the arbiter data register */
            for (i = 0u; i < length; i++)
            {
                pData[i] = CY_GET_REG8(p);
            }

            /* (re)arming of OUT endpoint */
            USBMIDI_EnableOutEP(epNumber);
        #else
            /*Init DMA if it was not initialized */
            if(USBMIDI_DmaTd[epNumber] == DMA_INVALID_TD)
            {
                USBMIDI_InitEP_DMA(epNumber, pData);
            }

        #endif /*  USBMIDI_EP_MM == USBMIDI__EP_MANUAL */

        #if(USBMIDI_EP_MM == USBMIDI__EP_DMAMANUAL)
            /* Enable DMA in mode2 for transferring data */
            (void) CyDmaChDisable(USBMIDI_DmaChan[epNumber]);
            (void) CyDmaTdSetConfiguration(USBMIDI_DmaTd[epNumber], length, CY_DMA_DISABLE_TD,
                                                                                TD_TERMIN_EN | TD_INC_DST_ADR);
            (void) CyDmaTdSetAddress(USBMIDI_DmaTd[epNumber],  LO16((uint32)p), LO16((uint32)pData));
            /* Enable the DMA */
            (void) CyDmaChSetInitialTd(USBMIDI_DmaChan[epNumber], USBMIDI_DmaTd[epNumber]);
            (void) CyDmaChEnable(USBMIDI_DmaChan[epNumber], 1u);

            /* Generate DMA request */
            * (reg8 *)(USBMIDI_ARB_EP1_CFG_IND + ri) |= USBMIDI_ARB_EPX_CFG_DMA_REQ;
            * (reg8 *)(USBMIDI_ARB_EP1_CFG_IND + ri) &= ((uint8)(~USBMIDI_ARB_EPX_CFG_DMA_REQ));
            /* Out EP will be (re)armed in arb ISR after transfer complete */
        #endif /*  USBMIDI_EP_MM == USBMIDI__EP_DMAMANUAL */

        #if(USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO)
            /* Enable DMA in mode3 for transferring data */
            (void) CyDmaChDisable(USBMIDI_DmaChan[epNumber]);
            (void) CyDmaTdSetConfiguration(USBMIDI_DmaTd[epNumber], length, USBMIDI_DmaTd[epNumber],
                                                                                TD_TERMIN_EN | TD_INC_DST_ADR);
            (void) CyDmaTdSetAddress(USBMIDI_DmaTd[epNumber],  LO16((uint32)p), LO16((uint32)pData));

            /* Clear Any potential pending DMA requests before starting the DMA channel to transfer data */
            (void) CyDmaClearPendingDrq(USBMIDI_DmaChan[epNumber]);
            /* Enable the DMA */
            (void) CyDmaChSetInitialTd(USBMIDI_DmaChan[epNumber], USBMIDI_DmaTd[epNumber]);
            (void) CyDmaChEnable(USBMIDI_DmaChan[epNumber], 1u);
            /* Out EP will be (re)armed in arb ISR after transfer complete */
        #endif /*  USBMIDI_EP_MM == USBMIDI__EP_DMAAUTO */

    }
    else
    {
        length = 0u;
    }

    return(length);
}


/*******************************************************************************
* Function Name: USBMIDI_EnableOutEP
********************************************************************************
*
* Summary:
*  This function enables an OUT endpoint.  It should not be
*  called for an IN endpoint.
*
* Parameters:
*  epNumber: Endpoint Number
*            Valid values are between 1 and 8.
*
* Return:
*   None.
*
* Global variables:
*  USBMIDI_EP[epNumber].apiEpState - set to NO_EVENT_PENDING
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_EnableOutEP(uint8 epNumber) 
{
    uint8 ri;

    if((epNumber > USBMIDI_EP0) && (epNumber < USBMIDI_MAX_EP))
    {
        ri = ((epNumber - USBMIDI_EP1) << USBMIDI_EPX_CNTX_ADDR_SHIFT);
        USBMIDI_EP[epNumber].apiEpState = USBMIDI_NO_EVENT_PENDING;
        /* Write the Mode register */
        CY_SET_REG8((reg8 *)(USBMIDI_SIE_EP1_CR0_IND + ri), USBMIDI_EP[epNumber].epMode);
    }
}


/*******************************************************************************
* Function Name: USBMIDI_DisableOutEP
********************************************************************************
*
* Summary:
*  This function disables an OUT endpoint.  It should not be
*  called for an IN endpoint.
*
* Parameters:
*  epNumber: Endpoint Number
*            Valid values are between 1 and 8.
*
* Return:
*  None.
*
*******************************************************************************/
void USBMIDI_DisableOutEP(uint8 epNumber) 
{
    uint8 ri ;

    if((epNumber > USBMIDI_EP0) && (epNumber < USBMIDI_MAX_EP))
    {
        ri = ((epNumber - USBMIDI_EP1) << USBMIDI_EPX_CNTX_ADDR_SHIFT);
        /* Write the Mode register */
        CY_SET_REG8((reg8 *)(USBMIDI_SIE_EP1_CR0_IND + ri), USBMIDI_MODE_NAK_OUT);
    }
}


/*******************************************************************************
* Function Name: USBMIDI_Force
********************************************************************************
*
* Summary:
*  Forces the bus state
*
* Parameters:
*  bState
*    USBMIDI_FORCE_J
*    USBMIDI_FORCE_K
*    USBMIDI_FORCE_SE0
*    USBMIDI_FORCE_NONE
*
* Return:
*  None.
*
*******************************************************************************/
void USBMIDI_Force(uint8 bState) 
{
    CY_SET_REG8(USBMIDI_USBIO_CR0_PTR, bState);
}


/*******************************************************************************
* Function Name: USBMIDI_GetEPAckState
********************************************************************************
*
* Summary:
*  Returns the ACK of the CR0 Register (ACKD)
*
* Parameters:
*  epNumber: Endpoint Number
*            Valid values are between 1 and 8.
*
* Returns
*  0 if nothing has been ACKD, non-=zero something has been ACKD
*
*******************************************************************************/
uint8 USBMIDI_GetEPAckState(uint8 epNumber) 
{
    uint8 ri;
    uint8 cr = 0u;

    if((epNumber > USBMIDI_EP0) && (epNumber < USBMIDI_MAX_EP))
    {
        ri = ((epNumber - USBMIDI_EP1) << USBMIDI_EPX_CNTX_ADDR_SHIFT);
        cr = CY_GET_REG8((reg8 *)(USBMIDI_SIE_EP1_CR0_IND + ri)) & USBMIDI_MODE_ACKD;
    }

    return(cr);
}


/*******************************************************************************
* Function Name: USBMIDI_SetPowerStatus
********************************************************************************
*
* Summary:
*  Sets the device power status for reporting in the Get Device Status
*  request
*
* Parameters:
*  powerStatus: USBMIDI_DEVICE_STATUS_BUS_POWERED(0) - Bus Powered,
*               USBMIDI_DEVICE_STATUS_SELF_POWERED(1) - Self Powered
*
* Return:
*   None.
*
* Global variables:
*  USBMIDI_deviceStatus - set power status
*
* Reentrant:
*  No.
*
*******************************************************************************/
void USBMIDI_SetPowerStatus(uint8 powerStatus) 
{
    if (powerStatus != USBMIDI_DEVICE_STATUS_BUS_POWERED)
    {
        USBMIDI_deviceStatus |=  USBMIDI_DEVICE_STATUS_SELF_POWERED;
    }
    else
    {
        USBMIDI_deviceStatus &=  ((uint8)(~USBMIDI_DEVICE_STATUS_SELF_POWERED));
    }
}


#if (USBMIDI_MON_VBUS == 1u)

    /*******************************************************************************
    * Function Name: USBMIDI_VBusPresent
    ********************************************************************************
    *
    * Summary:
    *  Determines VBUS presence for Self Powered Devices.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  1 if VBUS is present, otherwise 0.
    *
    *******************************************************************************/
    uint8 USBMIDI_VBusPresent(void) 
    {
        return((0u != (CY_GET_REG8(USBMIDI_VBUS_PS_PTR) & USBMIDI_VBUS_MASK)) ? 1u : 0u);
    }

#endif /* USBMIDI_MON_VBUS */


/*******************************************************************************
* Function Name: USBMIDI_RWUEnabled
********************************************************************************
*
* Summary:
*  Returns TRUE if Remote Wake Up is enabled, otherwise FALSE
*
* Parameters:
*   None.
*
* Return:
*  TRUE -  Remote Wake Up Enabled
*  FALSE - Remote Wake Up Disabled
*
* Global variables:
*  USBMIDI_deviceStatus - checked to determine remote status
*
*******************************************************************************/
uint8 USBMIDI_RWUEnabled(void) 
{
    uint8 result = USBMIDI_FALSE;
    if((USBMIDI_deviceStatus & USBMIDI_DEVICE_STATUS_REMOTE_WAKEUP) != 0u)
    {
        result = USBMIDI_TRUE;
    }

    return(result);
}


/* [] END OF FILE */
