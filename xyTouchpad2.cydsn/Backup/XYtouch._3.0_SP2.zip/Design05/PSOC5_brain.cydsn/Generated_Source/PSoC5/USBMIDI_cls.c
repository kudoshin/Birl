/*******************************************************************************
* File Name: USBMIDI_cls.c
* Version 2.70
*
* Description:
*  USB Class request handler.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "USBMIDI.h"

#if(USBMIDI_EXTERN_CLS == USBMIDI_FALSE)

#include "USBMIDI_pvt.h"


/***************************************
* User Implemented Class Driver Declarations.
***************************************/
/* `#START USER_DEFINED_CLASS_DECLARATIONS` Place your declaration here */

/* `#END` */


/*******************************************************************************
* Function Name: USBMIDI_DispatchClassRqst
********************************************************************************
* Summary:
*  This routine dispatches class specific requests depend on interface class.
*
* Parameters:
*  None.
*
* Return:
*  requestHandled.
*
* Reentrant:
*  No.
*
*******************************************************************************/
uint8 USBMIDI_DispatchClassRqst(void) 
{
    uint8 requestHandled = USBMIDI_FALSE;
    uint8 interfaceNumber = 0u;

    switch(CY_GET_REG8(USBMIDI_bmRequestType) & USBMIDI_RQST_RCPT_MASK)
    {
        case USBMIDI_RQST_RCPT_IFC:        /* Class-specific request directed to an interface */
            interfaceNumber = CY_GET_REG8(USBMIDI_wIndexLo); /* wIndexLo contain Interface number */
            break;
        case USBMIDI_RQST_RCPT_EP:         /* Class-specific request directed to the endpoint */
            /* Find related interface to the endpoint, wIndexLo contain EP number */
            interfaceNumber = USBMIDI_EP[CY_GET_REG8(USBMIDI_wIndexLo) & 
                              USBMIDI_DIR_UNUSED].interface;
            break;
        default:    /* RequestHandled is initialized as FALSE by default */
            break;
    }
    /* Handle Class request depend on interface type */
    switch(USBMIDI_interfaceClass[interfaceNumber])
    {
        case USBMIDI_CLASS_HID:
            #if defined(USBMIDI_ENABLE_HID_CLASS)
                requestHandled = USBMIDI_DispatchHIDClassRqst();
            #endif /* USBMIDI_ENABLE_HID_CLASS */
            break;
        case USBMIDI_CLASS_AUDIO:
            #if defined(USBMIDI_ENABLE_AUDIO_CLASS)
                requestHandled = USBMIDI_DispatchAUDIOClassRqst();
            #endif /* USBMIDI_CLASS_AUDIO */
            break;
        case USBMIDI_CLASS_CDC:
            #if defined(USBMIDI_ENABLE_CDC_CLASS)
                requestHandled = USBMIDI_DispatchCDCClassRqst();
            #endif /* USBMIDI_ENABLE_CDC_CLASS */
            break;
        default:    /* requestHandled is initialized as FALSE by default */
            break;
    }

    /* `#START USER_DEFINED_CLASS_CODE` Place your Class request here */

    /* `#END` */

    return(requestHandled);
}


/*******************************************************************************
* Additional user functions supporting Class Specific Requests
********************************************************************************/

/* `#START CLASS_SPECIFIC_FUNCTIONS` Place any additional functions here */

/* `#END` */

#endif /* USBMIDI_EXTERN_CLS */


/* [] END OF FILE */
