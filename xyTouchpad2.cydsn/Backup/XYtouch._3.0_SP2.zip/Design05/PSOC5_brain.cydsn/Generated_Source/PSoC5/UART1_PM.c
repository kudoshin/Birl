/*******************************************************************************
* File Name: UART1_PM.c
* Version 2.30
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "UART1.h"


/***************************************
* Local data allocation
***************************************/

static UART1_BACKUP_STRUCT  UART1_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: UART1_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART1_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART1_SaveConfig(void)
{
    #if (CY_UDB_V0)

        #if(UART1_CONTROL_REG_REMOVED == 0u)
            UART1_backup.cr = UART1_CONTROL_REG;
        #endif /* End UART1_CONTROL_REG_REMOVED */

        #if( (UART1_RX_ENABLED) || (UART1_HD_ENABLED) )
            UART1_backup.rx_period = UART1_RXBITCTR_PERIOD_REG;
            UART1_backup.rx_mask = UART1_RXSTATUS_MASK_REG;
            #if (UART1_RXHW_ADDRESS_ENABLED)
                UART1_backup.rx_addr1 = UART1_RXADDRESS1_REG;
                UART1_backup.rx_addr2 = UART1_RXADDRESS2_REG;
            #endif /* End UART1_RXHW_ADDRESS_ENABLED */
        #endif /* End UART1_RX_ENABLED | UART1_HD_ENABLED*/

        #if(UART1_TX_ENABLED)
            #if(UART1_TXCLKGEN_DP)
                UART1_backup.tx_clk_ctr = UART1_TXBITCLKGEN_CTR_REG;
                UART1_backup.tx_clk_compl = UART1_TXBITCLKTX_COMPLETE_REG;
            #else
                UART1_backup.tx_period = UART1_TXBITCTR_PERIOD_REG;
            #endif /*End UART1_TXCLKGEN_DP */
            UART1_backup.tx_mask = UART1_TXSTATUS_MASK_REG;
        #endif /*End UART1_TX_ENABLED */


    #else /* CY_UDB_V1 */

        #if(UART1_CONTROL_REG_REMOVED == 0u)
            UART1_backup.cr = UART1_CONTROL_REG;
        #endif /* End UART1_CONTROL_REG_REMOVED */

    #endif  /* End CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: UART1_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART1_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART1_RestoreConfig(void)
{

    #if (CY_UDB_V0)

        #if(UART1_CONTROL_REG_REMOVED == 0u)
            UART1_CONTROL_REG = UART1_backup.cr;
        #endif /* End UART1_CONTROL_REG_REMOVED */

        #if( (UART1_RX_ENABLED) || (UART1_HD_ENABLED) )
            UART1_RXBITCTR_PERIOD_REG = UART1_backup.rx_period;
            UART1_RXSTATUS_MASK_REG = UART1_backup.rx_mask;
            #if (UART1_RXHW_ADDRESS_ENABLED)
                UART1_RXADDRESS1_REG = UART1_backup.rx_addr1;
                UART1_RXADDRESS2_REG = UART1_backup.rx_addr2;
            #endif /* End UART1_RXHW_ADDRESS_ENABLED */
        #endif  /* End (UART1_RX_ENABLED) || (UART1_HD_ENABLED) */

        #if(UART1_TX_ENABLED)
            #if(UART1_TXCLKGEN_DP)
                UART1_TXBITCLKGEN_CTR_REG = UART1_backup.tx_clk_ctr;
                UART1_TXBITCLKTX_COMPLETE_REG = UART1_backup.tx_clk_compl;
            #else
                UART1_TXBITCTR_PERIOD_REG = UART1_backup.tx_period;
            #endif /*End UART1_TXCLKGEN_DP */
            UART1_TXSTATUS_MASK_REG = UART1_backup.tx_mask;
        #endif /*End UART1_TX_ENABLED */

    #else /* CY_UDB_V1 */

        #if(UART1_CONTROL_REG_REMOVED == 0u)
            UART1_CONTROL_REG = UART1_backup.cr;
        #endif /* End UART1_CONTROL_REG_REMOVED */

    #endif  /* End CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: UART1_Sleep
********************************************************************************
*
* Summary:
*  Stops and saves the user configuration. Should be called
*  just prior to entering sleep.
*
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART1_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART1_Sleep(void)
{

    #if(UART1_RX_ENABLED || UART1_HD_ENABLED)
        if((UART1_RXSTATUS_ACTL_REG  & UART1_INT_ENABLE) != 0u)
        {
            UART1_backup.enableState = 1u;
        }
        else
        {
            UART1_backup.enableState = 0u;
        }
    #else
        if((UART1_TXSTATUS_ACTL_REG  & UART1_INT_ENABLE) !=0u)
        {
            UART1_backup.enableState = 1u;
        }
        else
        {
            UART1_backup.enableState = 0u;
        }
    #endif /* End UART1_RX_ENABLED || UART1_HD_ENABLED*/

    UART1_Stop();
    UART1_SaveConfig();
}


/*******************************************************************************
* Function Name: UART1_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called
*  just after awaking from sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART1_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART1_Wakeup(void)
{
    UART1_RestoreConfig();
    #if( (UART1_RX_ENABLED) || (UART1_HD_ENABLED) )
        UART1_ClearRxBuffer();
    #endif /* End (UART1_RX_ENABLED) || (UART1_HD_ENABLED) */
    #if(UART1_TX_ENABLED || UART1_HD_ENABLED)
        UART1_ClearTxBuffer();
    #endif /* End UART1_TX_ENABLED || UART1_HD_ENABLED */

    if(UART1_backup.enableState != 0u)
    {
        UART1_Enable();
    }
}


/* [] END OF FILE */
